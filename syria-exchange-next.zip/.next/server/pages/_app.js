(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7488:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var i18next_browser_languagedetector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6071);
/* harmony import */ var i18next_browser_languagedetector__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18next_browser_languagedetector__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__]);
i18next__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use((i18next_browser_languagedetector__WEBPACK_IMPORTED_MODULE_2___default()))// pass the i18n instance to react-i18next.
.use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next)// init i18next
// for all options read: https://www.i18next.com/overview/configuration-options
.init({
    debug: true,
    fallbackLng: "en",
    interpolation: {
        escapeValue: false
    },
    resources: {
        en: {
            translation: {
                description: {
                    headerHome: "Home",
                    headerSYP: "Syrian Pound",
                    headerGold: "Gold",
                    headerTRY: "Turkish Lira",
                    headerIterCoins: "International Coins",
                    headerNews: "News",
                    headerDownload: "Download App",
                    headerReload: "Reload",
                    headerCERTitle: "Currency Exchange Rate",
                    headerCERCurr: "Currency",
                    headerCERCurrBuy: "Buy",
                    headerCERCurrSell: "Sell",
                    headerCERSeeMore: "See More +",
                    CentralbankTitle: "Official Rates In The Central Bank",
                    CurrConverterTitle: "Currency Converter",
                    CurrConverterPlaceHolder1: "Enter Amount Here ....",
                    CurrConverterFrom: "From",
                    CurrConverterTo: "To",
                    CurrConverterPlaceHolder2: "Result",
                    GoldPricesTitle: "Gold Prices",
                    MetalType: "Metal Type",
                    SYP: "SYP",
                    USD: "USD",
                    SyriaNews: "Syria News",
                    AllNews: "All News",
                    AdvertiseWithUs: "Advertise With Us",
                    GetApi: "Get API",
                    AboutUs: "About Us",
                    copyRights: "All rights reserved to the site",
                    internationalCoinsTitle: "International Coins",
                    TRYHeaderCERTitle: "Currency Exchange Rate Against The Turkish Lira",
                    TRYGoldTitle: "Gold and Metal Prices in Turkey",
                    TurkeyNews: "Turkey News",
                    exchangeRate: "Exchange Rate",
                    GoldRate: "Gold Rate",
                    financialAdvices: "Financial Advices",
                    chooseCategory: "Choose Category",
                    ApiService: "API Service",
                    ApiServiceParagraph: "On our Syria Exchange website, we offer an API service, which provides you with our website data for use within your projects.",
                    ApiOurService: "Why our service is the best?",
                    ApiOurServiceParagraph1: "Because we offer reliable and accurate exchange rates for the Syrian pound for more than 15 Syrian cities",
                    ApiOurServiceParagraph2: "We offer exchange rates for 42 Arab and international currencies with instant and accurate change according to any currency",
                    ApiOurServiceParagraph3: "And also the international gold and silver prices and their pricing against each currency, which are updated according to the global market.",
                    FeaturesOfOurServices: "Features of our services",
                    FeaturesOfOurServicesParagraph1: "Access to the exchange rates of the Syrian pound against 42 currencies in more than 15 Syrian cities",
                    FeaturesOfOurServicesParagraph2: "Access to the exchange rates of Arab and international currencies",
                    FeaturesOfOurServicesParagraph3: "Access to gold and silver prices according to any currency",
                    FeaturesOfOurServicesParagraph4: "Easily integrate data into your website",
                    FeaturesOfOurServicesParagraph5: "Reliable prices and updated in real time",
                    FeaturesOfOurServicesParagraph6: "Various packages to suit your business needs",
                    FeaturesOfOurServicesParagraph7: "A special page for each customer, through which he can see the size of the package and the amount of daily exchange",
                    FeaturesOfOurServicesParagraph8: "Multiple payment methods to suit everyone",
                    FeaturesOfOurServicesParagraph9: "The API is accessed via HTTP GET in JSON format.",
                    contactUs: "You can contact us via the website mail",
                    contactUsOr: "Or by sending us a message on Messenger",
                    adWithUs: "Advertise with us",
                    adWithUsIntro: "At the outset, we would like to thank you for your desire to advertise with us, as the Syria Exchange website is one of the largest Arab and Syrian websites specialized in publishing Arab and international exchange rates at the level of Syrian governorates and cities, as well as publishing gold and silver prices, as well as publishing posts that are concerned with economic conditions, financial advice and local news. On a daily basis.",
                    WhyAdWithUs: "Why advertise with us?",
                    WhyAdWithUsParagraph: "Syria Exchange is one of the best sites that get daily visits significantly, which gives the opportunity to display your ads more to visitors, so the return The investment will be special, God willing.",
                    TypeOfAds: "Types of ads",
                    TypeOfAdsPara1: "On our site, we provide specific packages to display your ads in different sizes",
                    TypeOfAdsPara2: "Banner ad size 1052*618",
                    TypeOfAdsPara3: "Banner ad size 320*250",
                    TypeOfAdsPara4: "It is prohibited to display advertisements that contain women, alcohol, franks, or chat sites. We reserve the right to reject any advertisement",
                    AboutUsPara1: "Syria Exchange is a non-profit organization that provides its services to the Arab public in all countries of the world to know the rates of international and Arab currencies and link them with gold prices and follow up on all news and global markets moment by moment in order to facilitate financial transactions and manage them correctly and properly with the aim in the end to serve the Arab public and increase investment opportunities Improving the lives of citizens",
                    AboutUsPara2: "We do not have any centers or offices for money transfer or money exchange services in any country, we provide currency rates with high accuracy through global markets, moment by moment only.",
                    AboutUsPara3: "At Syria Exchange, we seek, through the news blog service, to provide financial advice, present new ideas, and increase cooperation between countries by knowing the cultures of different peoples, spreading financial awareness and enriching knowledge in the Arab world, which in turn contribute to creating new job opportunities in the field of financial transactions, business and investment.",
                    AboutUsPara4: "It aims to serve people and help them in providing currency data for all the most traded Arab and international countries and finding solutions to facilitate financial transactions between countries and create a world full of cooperation and love in financial and commercial transactions to achieve the highest return for all.",
                    AboutUsPara5: "Through our team, we seek to facilitate financial and investment services and provide all data for any currency without effort or trouble, while providing access to all information and answers to all inquiries.. In order to provide the best services always",
                    news: "News",
                    readMore: "Read More",
                    change: "Change",
                    PrivacyPolicy: {
                        title: "Privacy Policy",
                        introText1: "At (Syria Exchange), we understand that the privacy of your personal information is important to you and us.",
                        introText2: "Below is information about the types of personal information we receive and collect when you visit https://syria-exchange.com, How we protect your personal information. Log files As with most different websites, we collect and use the data contained in log files. The information in log files includes your Internet Protocol (IP) address, your Internet service provider (ISP), the browser you used to visit our site, The time you visited and the pages you visited on our website.",
                        cookies: {
                            title: "Cookies:",
                            text: " We use cookies to give you the best possible experience on a simple website, for more information about cookies, Visit: http://www.allaboutcookies.org/."
                        },
                        essentialCookies: {
                            title: "Essential Cookies:",
                            text: " Essential cookies are essential for you to navigate and navigate around the site, It does not store any information that can be used for advertising purposes, without essential cookies our website will not function properly."
                        },
                        customCookies: {
                            title: "Custom cookies:",
                            text: " These cookies store information, such as your personal preferences, and use it to customize a unique experience for you. This may include displaying a popup once only one per your visit, save your language preferences, or allow you to automatically sign in to some of our features."
                        },
                        analyticalCookies: {
                            title: "Analytics Cookies:",
                            text: " Analytics cookies capture anonymous data so that we can see trends and improve our website experience. These allow us to test different designs, And help us identify a break if part of our site isn't working."
                        },
                        advertisingCookies: {
                            title: "Advertising Cookies:",
                            terms: [
                                "Some third party advertisers may use cookies or web beacons when advertising on our site. They will send information to these advertisers (such as Google through Google AdSense) including your IP address, ISP, and the browser you used to visit our site, and in some cases information about whether you have Flash installed.",
                                "Third party vendors, including Google, use cookies to serve ads based on a user's previous visits to our website or other websites.",
                                "By using advertising cookies, Google and its partners will be able to serve ads to your users based on their visits to our site and/or other sites on the Internet.",
                                " Users can disable the use of personalized advertising by going to Ads Settings.", 
                            ]
                        },
                        outroText1: "If you have not opted out from displaying third-party advertisements, cookies from other third-party ad networks or vendors may also be used to display advertisements on our site. This is generally used for geo-targeting purposes eg (showing SEO ads in Germany to someone in Germany) or showing specific ads based on specific locations Visited (eg showing real estate ads to someone who frequents real estate websites).",
                        outroText2: "By continuing to use our website, you agree to the placement of cookies on your device. You can choose to disable or turn off cookies or third party cookies The third is selectively in your browser settings. However, this can affect how you interact with our site as well as with other websites. If you have any questions or if there is any problem here, Our data usage policy, please contact us through the contact us page ",
                        emailContact: "or Contact Us at"
                    },
                    UserAgreement: {
                        title: "User Agreement",
                        introText: "By using the Syria Exchange website, you agree to be bound by the stipulated terms and conditions, so you should read and take these provisions into consideration:",
                        condition1: {
                            title: "Accept the Agreement",
                            terms: [
                                "By your use of this website, this indicates your complete acceptance of all terms and conditions stated here",
                                "You should not use this website if you do not agree to any of these standard terms and conditions.",
                                "Our Terms and Conditions are created in the Terms and Conditions form and Privacy Policy form.",
                                "The use of this site is prohibited for persons under the age of 18 years.", 
                            ]
                        },
                        condition2: {
                            title: "Sole Proprietorship Rights",
                            terms: [
                                "All trademarks displayed on this website are the property of it. Also, all content displayed on this site, including images, music, graphics, and others, are the exclusive property of the site and cannot be used without obtaining permission from the site owner.",
                                "We provide you with the authority to browse the site and reuse some content for personal purposes only. It is not permissible in any way to use the site for commercial purposes or to integrate the site with another site except after agreement with us and a partnership contract with us. In the event that one of the persons or sites does it, he will be subject to legal accountability.", 
                            ]
                        },
                        condition3: {
                            title: "Limitations",
                            text: "If you use this website, you are prohibited from doing the following:",
                            terms: [
                                "Using the website in an illegal manner or violating the privacy policy.",
                                "Doing any behavior that would disrupt, damage or damage the Site and interfere with the work or private content of the Site or with the use of any other person.",
                                "Using this site for the purpose of advertising, marketing or publicity without prior permission from the site owner.",
                                "Spreading hate, racism, obscene speech, or defamation of a person or a site where this exposes you to legal accountability.",
                                "Removing one of the copyright notices or any other notices of intellectual property rights from the site or content available on or through the site. Your conduct of any of the previous activities in violation of the site's policy exposes you to legal issues.", 
                            ]
                        },
                        condition4: {
                            title: "Disclaimer",
                            text: "Your access to the Site and your use of its content is at your own risk. The information we provide is for general information purposes only. All information on the website is provided in good faith. However, we make no representation or warranty of any kind, express or implied, as to the accuracy, adequacy, correctness, reliability, availability or completeness of any information on the Site."
                        },
                        condition5: {
                            title: "Your privacy",
                            text: "Please read the privacy policy and your content must be an individual right provided that it does not violate the rights of the site. The site also has the authority to remove any of your content without prior notice."
                        }
                    }
                }
            }
        },
        ar: {
            translation: {
                description: {
                    headerHome: "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
                    headerSYP: "\u0627\u0644\u0644\u064A\u0631\u0629 \u0627\u0644\u0633\u0648\u0631\u064A\u0629",
                    headerGold: "\u0627\u0644\u0630\u0647\u0628",
                    headerTRY: "\u0627\u0644\u0644\u064A\u0631\u0629 \u0627\u0644\u062A\u0631\u0643\u064A\u0629",
                    headerIterCoins: "\u0639\u0645\u0644\u0627\u062A \u0639\u0627\u0644\u0645\u064A\u0629",
                    headerNews: "\u0627\u0644\u0623\u062E\u0628\u0627\u0631",
                    headerDownload: "\u062D\u0645\u0644 \u0627\u0644\u062A\u0637\u0628\u064A\u0642",
                    headerReload: "\u062A\u062D\u062F\u064A\u062B",
                    headerCERTitle: "\u0633\u0639\u0631 \u0635\u0631\u0641 \u0627\u0644\u0639\u0645\u0644\u0627\u062A",
                    headerCERCurr: "\u0627\u0644\u0639\u0645\u0644\u0629",
                    headerCERCurrBuy: "\u0634\u0631\u0627\u0621",
                    headerCERCurrSell: "\u0645\u0628\u064A\u0639",
                    headerCERSeeMore: " + \u0645\u0634\u0627\u0647\u062F\u0629 \u0627\u0644\u0645\u0632\u064A\u062F",
                    CentralbankTitle: " \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0631\u0633\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0628\u0646\u0643 \u0627\u0644\u0645\u0631\u0643\u0632\u064A",
                    CurrConverterTitle: "\u0645\u062D\u0648\u0644 \u0627\u0644\u0639\u0645\u0644\u0627\u062A ",
                    CurrConverterPlaceHolder1: "\u0623\u062F\u062E\u0644 \u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0628\u0644\u063A \u0647\u0646\u0627....",
                    CurrConverterFrom: "\u0645\u0646",
                    CurrConverterTo: "\u0625\u0644\u0649",
                    CurrConverterPlaceHolder2: "\u0627\u0644\u0646\u0627\u062A\u062C",
                    GoldPricesTitle: "\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0630\u0647\u0628 ",
                    MetalType: "\u0646\u0648\u0639 \u0627\u0644\u0645\u0639\u062F\u0646 ",
                    SYP: "\u0644.\u0633",
                    USD: "\u062F\u0648\u0644\u0627\u0631",
                    SyriaNews: "\u0623\u062E\u0628\u0627\u0631 \u0633\u0648\u0631\u064A\u0629",
                    AllNews: "\u0643\u0644 \u0627\u0644\u0623\u062E\u0628\u0627\u0631",
                    AdvertiseWithUs: "\u0623\u0639\u0640\u0640\u0644\u0640\u0640\u0640\u0646 \u0644\u0640\u0640\u062F\u064A\u0640\u0640\u0646\u0640\u0640\u0627",
                    GetApi: "\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 API",
                    AboutUs: "\u0645\u0640\u0640\u0640\u0640\u0640\u0646 \u0646\u0640\u0640\u0640\u0640\u0640\u062D\u0640\u0640\u0640\u0640\u0640\u0640\u0646",
                    copyRights: "\u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0642\u0648\u0642 \u0645\u062D\u0641\u0648\u0638\u0629 \u0644\u0645\u0648\u0642\u0639",
                    internationalCoinsTitle: "\u0639\u0645\u0644\u0627\u062A \u0639\u0627\u0644\u0645\u064A\u0629",
                    TRYHeaderCERTitle: "\u0633\u0639\u0631 \u0635\u0631\u0641 \u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0645\u0642\u0627\u0628\u0644 \u0627\u0644\u0644\u064A\u0631\u0629 \u0627\u0644\u062A\u0631\u0643\u064A\u0629",
                    TRYGoldTitle: "\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0630\u0647\u0628 \u0648\u0627\u0644\u0645\u0639\u0627\u062F\u0646 \u0641\u064A \u062A\u0631\u0643\u064A\u0627",
                    TurkeyNews: "\u0623\u062E\u0628\u0627\u0631 \u062A\u0631\u0643\u064A\u0627",
                    exchangeRate: "\u0633\u0639\u0631 \u0635\u0631\u0641",
                    GoldRate: "\u0633\u0639\u0631 \u0630\u0647\u0628",
                    financialAdvices: "\u0646\u0635\u0627\u0626\u062D \u0645\u0627\u0644\u064A\u0629",
                    chooseCategory: "\u0627\u062E\u062A\u0631 \u0641\u0626\u0629",
                    ApiService: "\u062E\u062F\u0645\u0629 API",
                    ApiServiceParagraph: "\u0646\u0642\u062F\u0645 \u0641\u064A \u0645\u0648\u0642\u0639\u0646\u0627 \u0633\u0648\u0631\u064A\u0627 \u0644\u0644\u0635\u0631\u0627\u0641\u0629 \u062E\u062F\u0645\u0629 API \u0648\u0627\u0644\u062A\u064A \u062A\u0648\u0641\u0631 \u0644\u0643\u0645 \u0628\u064A\u0627\u0646\u0627\u062A \u0645\u0648\u0642\u0639\u0646\u0627 \u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647\u0627 \u0636\u0645\u0646 \u0645\u0634\u0627\u0631\u064A\u0639\u0643\u0645.",
                    ApiOurService: "\u0644\u0645\u0627\u0630\u0627 \u062E\u062F\u0645\u062A\u0646\u0627 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u061F",
                    ApiOurServiceParagraph1: "\u0644\u0623\u0646\u0646\u0627 \u0646\u0642\u062F\u0645 \u0623\u0633\u0639\u0627\u0631 \u0635\u0631\u0641 \u0627\u0644\u0644\u064A\u0631\u0629 \u0627\u0644\u0633\u0648\u0631\u064A\u0629 \u0645\u0648\u062B\u0648\u0642\u0629 \u0648\u0628\u0634\u0643\u0644 \u062F\u0642\u064A\u0642 \u0644\u0623\u0643\u062B\u0631 \u0645\u0646 15 \u0645\u062F\u064A\u0646\u0629 \u0633\u0648\u0631\u064A\u0629",
                    ApiOurServiceParagraph2: "\u0646\u0642\u062F\u0645 \u0623\u0633\u0639\u0627\u0631 \u0635\u0631\u0641 \u0644 42 \u0639\u0645\u0644\u0629 \u0639\u0631\u0628\u064A\u0629 \u0648\u0639\u0627\u0644\u0645\u064A\u0629 \u0648\u0628\u062A\u063A\u064A\u064A\u0631 \u0644\u062D\u0638\u064A \u0648\u062F\u0642\u064A\u0642 \u062D\u0633\u0628 \u0623\u064A \u0639\u0645\u0644\u0629",
                    ApiOurServiceParagraph3: "\u0648\u0623\u064A\u0636\u0627\u064B \u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0630\u0647\u0628 \u0648\u0627\u0644\u0641\u0636\u0629 \u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629 \u0648\u062A\u0633\u0639\u064A\u0631\u0647\u0627 \u0645\u0642\u0627\u0628\u0644 \u0643\u0644 \u0639\u0645\u0644\u0629 \u0648\u0627\u0644\u062A\u064A \u064A\u062A\u0645 \u062A\u062D\u062F\u064A\u062B\u0647\u0627 \u062D\u0633\u0628 \u0627\u0644\u0633\u0648\u0642 \u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629",
                    FeaturesOfOurServices: "\u0645\u0645\u064A\u0632\u0627\u062A \u062E\u062F\u0645\u0627\u062A\u0646\u0627",
                    FeaturesOfOurServicesParagraph1: "\u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0623\u0633\u0639\u0627\u0631 \u0635\u0631\u0641 \u0627\u0644\u0644\u064A\u0631\u0629 \u0627\u0644\u0633\u0648\u0631\u064A\u0629 \u0645\u0642\u0627\u0628\u0644 42 \u0639\u0645\u0644\u0629 \u0641\u064A \u0623\u0643\u062B\u0631 \u0645\u0646 15 \u0645\u062F\u064A\u0646\u0629 \u0633\u0648\u0631\u064A\u0629",
                    FeaturesOfOurServicesParagraph2: "\u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0623\u0633\u0639\u0627\u0631 \u0635\u0631\u0641 \u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0648\u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629",
                    FeaturesOfOurServicesParagraph3: "\u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0630\u0647\u0628 \u0648\u0627\u0644\u0641\u0636\u0629 \u062D\u0633\u0628 \u0623\u064A \u0639\u0645\u0644\u0629",
                    FeaturesOfOurServicesParagraph4: "\u062F\u0645\u062C \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0641\u064A \u0645\u0648\u0642\u0639\u0643\u0645 \u0628\u0633\u0647\u0648\u0644\u0629",
                    FeaturesOfOurServicesParagraph5: "\u0627\u0633\u0639\u0627\u0631 \u0645\u0648\u062B\u0648\u0642\u0629 \u0648\u064A\u062A\u0645 \u062A\u062D\u062F\u064A\u062B\u0647\u0627 \u0628\u0634\u0643\u0644 \u0644\u062D\u0638\u064A",
                    FeaturesOfOurServicesParagraph6: "\u0628\u0627\u0642\u0627\u062A \u0645\u062A\u0646\u0648\u0639\u0629 \u062A\u0646\u0627\u0633\u0628 \u0627\u062D\u062A\u064A\u0627\u062C\u0627\u062A \u0623\u0639\u0645\u0627\u0644\u0643",
                    FeaturesOfOurServicesParagraph7: "\u0635\u0641\u062D\u0629 \u062E\u0627\u0635\u0629 \u0644\u0643\u0644 \u0639\u0645\u064A\u0644 \u064A\u0645\u0643\u0646\u0647 \u0645\u0646 \u062E\u0644\u0627\u0644\u0647\u0627 \u0627\u0644\u0627\u0637\u0644\u0627\u0639 \u0639\u0644\u0649 \u062D\u062C\u0645 \u0627\u0644\u0628\u0627\u0642\u0629 \u0648\u0645\u0642\u062F\u0627\u0631 \u0627\u0644\u0635\u0631\u0641 \u0627\u0644\u064A\u0648\u0645\u064A",
                    FeaturesOfOurServicesParagraph8: "\u0637\u0631\u0642 \u062F\u0641\u0639 \u0645\u062A\u0639\u062F\u062F\u0629 \u062A\u0646\u0627\u0633\u0628 \u0627\u0644\u062C\u0645\u064A\u0639",
                    FeaturesOfOurServicesParagraph9: "\u064A\u062A\u0645 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 API \u0639\u0628\u0631 HTTP GET \u0628\u062A\u0646\u0633\u064A\u0642 JSON .",
                    contactUs: "\u064A\u0645\u0643\u0646 \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627 \u0639\u0628\u0631 \u0628\u0631\u064A\u062F \u0627\u0644\u0645\u0648\u0642\u0639",
                    contactUsOr: "\u0623\u0648 \u0639\u0628\u0631 \u0645\u0631\u0627\u0633\u0644\u062A\u0646\u0627 \u0639\u0644\u0649 \u0645\u0627\u0633\u0646\u062C\u0631",
                    adWithUs: "\u0623\u0639\u0644\u0646 \u0644\u062F\u064A\u0646\u0627",
                    adWithUsIntro: "\u0641\u064A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0646\u0648\u062F \u0623\u0646 \u0646\u0634\u0643\u0631\u0643\u0645 \u0639\u0644\u0649 \u0631\u063A\u0628\u062A\u0643\u0645 \u0641\u064A \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0645\u0639\u0646\u0627\u060C\u062D\u064A\u062B \u064A\u0639\u062A\u0628\u0631 \u0645\u0648\u0642\u0639\u0633\u0648\u0631\u064A\u0627 \u0644\u0644\u0635\u0631\u0627\u0641\u0629 \u0645\u0646 \u0623\u0643\u0628\u0631 \u0627\u0644\u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0648\u0627\u0644\u0633\u0648\u0631\u064A\u0629 \u0627\u0644\u0645\u062A\u062E\u0635\u0635\u0629 \u0641\u064A \u0646\u0634\u0631 \u0623\u0633\u0639\u0627\u0631 \u0635\u0631\u0641 \u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0648\u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629 \u0639\u0644\u0649 \u0645\u0633\u062A\u0648\u0649 \u0627\u0644\u0645\u062D\u0627\u0641\u0638\u0627\u062A \u0648\u0627\u0644\u0645\u062F\u0646 \u0627\u0644\u0633\u0648\u0631\u064A\u0629 \u0648\u0623\u064A\u0636\u0627\u064B \u0646\u0634\u0631 \u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0630\u0647\u0628 \u0648\u0627\u0644\u0641\u0636\u0629 \u0648\u0623\u064A\u0636\u0627\u064B \u064A\u062A\u0645 \u0646\u0634\u0631 \u0627\u0644\u062A\u062F\u0648\u064A\u0646\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0647\u062A\u0645 \u0628\u0627\u0644\u0623\u0648\u0636\u0627\u0639 \u0627\u0644\u0627\u0642\u062A\u0635\u0627\u062F\u064A\u0629 \u0648\u0627\u0644\u0646\u0635\u0627\u0626\u062D \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0648\u0627\u0644\u0623\u062E\u0628\u0627\u0631 \u0627\u0644\u0645\u062D\u0644\u064A\u0629 \u0628\u0634\u0643\u0644 \u064A\u0648\u0645\u064A.",
                    WhyAdWithUs: "\u0644\u0645\u0627\u0630\u0627 \u062A\u0639\u0644\u0646 \u0644\u062F\u064A\u0646\u0627 \u061F ",
                    WhyAdWithUsParagraph: " \u064A\u0639\u062A\u0628\u0631 \u0645\u0648\u0642\u0639 \u0633\u0648\u0631\u064A\u0627 \u0644\u0644\u0635\u0631\u0627\u0641\u0629 \u0645\u0646 \u0623\u0641\u0636\u0644 \u0627\u0644\u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u062A\u064A \u062A\u062D\u0635\u0644 \u0639\u0644\u0649 \u0632\u064A\u0627\u0631\u0627\u062A \u064A\u0648\u0645\u064A\u0629 \u0628\u0634\u0643\u0644 \u0643\u0628\u064A\u0631 \u0645\u0645\u0627 \u064A\u062A\u064A\u062D \u0627\u0644\u0641\u0631\u0635\u0629 \u0644\u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0627\u062A\u0643\u0645 \u0628\u0634\u0643\u0644 \u0623\u0643\u0628\u0631 \u0644\u0644\u0632\u0627\u0626\u0631\u064A\u0646 \u0644\u0630\u0627 \u0627\u0644\u0639\u0627\u0626\u062F \u0627\u0644\u0627\u0633\u062A\u062B\u0645\u0627\u0631\u064A \u0633\u064A\u0643\u0648\u0646 \u0645\u0645\u064A\u0632\u0627\u064B \u0628\u0625\u0630\u0646 \u0627\u0644\u0644\u0647 \u062A\u0639\u0627\u0644\u0649.",
                    TypeOfAds: "\u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A",
                    TypeOfAdsPara1: "\u0646\u0648\u0641\u0631 \u0641\u064A \u0645\u0648\u0642\u0639\u0646\u0627 \u0628\u0627\u0642\u0627\u062A \u0645\u062D\u062F\u062F\u0629 \u0644\u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0627\u062A\u0643\u0645 \u0648\u0628\u0645\u0642\u0627\u0633\u0627\u062A \u0645\u062E\u062A\u0644\u0641\u0629",
                    TypeOfAdsPara2: "\u0625\u0639\u0644\u0627\u0646 \u0628\u0646\u0631 \u0628\u0645\u0642\u0627\u0633 1052*618",
                    TypeOfAdsPara3: "\u0625\u0639\u0644\u0627\u0646 \u0628\u0646\u0631 \u0628\u0645\u0642\u0627\u0633 320*250",
                    TypeOfAdsPara4: "\u064A\u0645\u0646\u0639 \u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062D\u062A\u0648\u0649 \u0639\u0644\u0649 \u0627\u0644\u0646\u0633\u0627\u0621 \u0627\u0648 \u0627\u0644\u062E\u0645\u0648\u0631 \u0627\u0648 \u0627\u0644\u0641\u0631\u0648\u0643\u0633 \u0627\u0648 \u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u062F\u0631\u062F\u0634\u0629. \u0648\u0646\u062D\u062A\u0641\u0638 \u0628\u062D\u0642\u0646\u0627 \u0641\u064A \u0631\u0641\u0636 \u0623\u064A \u0625\u0639\u0644\u0627\u0646",
                    AboutUsPara1: "\u0633\u0648\u0631\u064A\u0627 \u0644\u0644\u0635\u0631\u0627\u0641\u0629 \u0647\u064A \u0645\u0624\u0633\u0633\u0629 \u063A\u064A\u0631 \u0631\u0628\u062D\u064A\u0629 \u062A\u0642\u062F\u0645 \u062E\u062F\u0645\u0627\u062A\u0647\u0627 \u0625\u0644\u0649 \u0627\u0644\u062C\u0645\u0647\u0648\u0631 \u0627\u0644\u0639\u0631\u0628\u064A \u0641\u064A \u062C\u0645\u064A\u0639 \u062F\u0648\u0644 \u0627\u0644\u0639\u0627\u0644\u0645 \u0644\u0645\u0639\u0631\u0641\u0629 \u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629 \u0648\u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0648\u0631\u0628\u0637\u0647\u0627 \u0645\u0639 \u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0630\u0647\u0628 \u0648\u0645\u062A\u0627\u0628\u0639\u0629 \u062C\u0645\u064A\u0639 \u0627\u0644\u0623\u062E\u0628\u0627\u0631 \u0648\u0627\u0644\u0623\u0633\u0648\u0627\u0642 \u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629 \u0644\u062D\u0638\u0629 \u0628\u0644\u062D\u0638\u0629 \u0645\u0646 \u0623\u062C\u0644 \u062A\u0633\u0647\u064A\u0644 \u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0648\u0625\u062F\u0627\u0631\u062A\u0647\u0627 \u0628\u0634\u0643\u0644 \u0635\u062D\u064A\u062D \u0648\u0633\u0644\u064A\u0645 \u0628\u0645\u0627 \u064A\u0647\u062F\u0641 \u0641\u064A \u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u0644\u062E\u062F\u0645\u0629 \u0627\u0644\u062C\u0645\u0647\u0648\u0631 \u0627\u0644\u0639\u0631\u0628\u064A \u0648\u0632\u064A\u0627\u062F\u0629 \u0627\u0644\u0641\u0631\u0635 \u0627\u0644\u0627\u0633\u062A\u062B\u0645\u0627\u0631\u064A\u0629 \u0648\u062A\u062D\u0633\u064A\u0646 \u0623\u0634\u0643\u0627\u0644 \u0627\u0644\u062D\u064A\u0627\u0629 \u0644\u0644\u0645\u0648\u0627\u0637\u0646\u064A\u0646",
                    AboutUsPara2: "\u0644\u064A\u0633 \u0644\u062F\u064A\u0646\u0627 \u0623\u064A \u0645\u0631\u0627\u0643\u0632 \u0623\u0648 \u0645\u0643\u0627\u062A\u0628 \u0644\u062E\u062F\u0645\u0627\u062A \u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u0623\u0645\u0648\u0627\u0644 \u0623\u0648 \u0627\u0635\u0631\u064A\u0641 \u0627\u0644\u0623\u0645\u0648\u0627\u0644 \u0641\u064A \u0623\u064A \u062F\u0648\u0644\u0629\u060C \u0646\u062D\u0646 \u0646\u0648\u0641\u0631 \u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0628\u062F\u0642\u0629 \u0639\u0627\u0644\u064A\u0629 \u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0644\u0623\u0633\u0648\u0627\u0642 \u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629 \u0644\u062D\u0638\u0629 \u0628\u0644\u062D\u0638\u0629 \u0641\u0642\u0637.",
                    AboutUsPara3: "\u0646\u0633\u0639\u0649 \u0641\u064A \u0645\u0624\u0633\u0633\u0629 \u0633\u0648\u0631\u064A\u0627 \u0644\u0644\u0635\u0631\u0627\u0641\u0629 \u0645\u0646 \u062E\u0644\u0627\u0644 \u062E\u062F\u0645\u0629 \u0627\u0644\u0645\u062F\u0648\u0646\u0629 \u0627\u0644\u0625\u062E\u0628\u0627\u0631\u064A\u0629 \u0625\u0644\u0649 \u062A\u0642\u062F\u064A\u0645 \u0627\u0644\u0646\u0635\u0627\u0626\u062D \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0648\u0637\u0631\u062D \u0623\u0641\u0643\u0627\u0631 \u062C\u062F\u064A\u062F\u0629 \u0648\u0632\u064A\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u0627\u0648\u0646 \u0628\u064A\u0646 \u0627\u0644\u062F\u0648\u0644 \u0645\u0646 \u062E\u0644\u0627\u0644 \u0645\u0639\u0631\u0641\u0629 \u062B\u0642\u0627\u0641\u0627\u062A \u0627\u0644\u0634\u0639\u0648\u0628 \u0627\u0644\u0645\u062E\u062A\u0644\u0641\u0629 \u0648\u0646\u0634\u0631 \u0627\u0644\u0648\u0639\u064A \u0627\u0644\u0645\u0627\u0644\u064A \u0648\u0625\u062B\u0631\u0627\u0621 \u0627\u0644\u0645\u0639\u0631\u0641\u0629 \u0641\u064A \u0627\u0644\u0639\u0627\u0644\u0645 \u0627\u0644\u0639\u0631\u0628\u064A \u0648\u0627\u0644\u062A\u064A \u062A\u0633\u0627\u0647\u0645 \u0628\u062F\u0648\u0631\u0647\u0627 \u0641\u064A \u062E\u0644\u0642 \u0641\u0631\u0635 \u0639\u0645\u0644 \u062C\u062F\u064A\u062F\u0629 \u0641\u064A \u0645\u062C\u0627\u0644 \u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0648\u0627\u0644\u0623\u0639\u0645\u0627\u0644 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629 \u0648\u0627\u0644\u0627\u0633\u062A\u062B\u0645\u0627\u0631.",
                    AboutUsPara4: "\u0648\u062A\u0647\u062F\u0641 \u0625\u0644\u0649 \u062E\u062F\u0645\u0629 \u0627\u0644\u0646\u0627\u0633 \u0648\u0645\u0633\u0627\u0639\u062F\u062A\u0647\u0645 \u0641\u064A \u062A\u0648\u0641\u064A\u0631 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0644\u062C\u0645\u064A\u0639 \u0627\u0644\u062F\u0648\u0644 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0648\u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629 \u0627\u0644\u0623\u0643\u062B\u0631 \u062A\u062F\u0627\u0648\u0644\u0627\u064B \u0648\u0625\u064A\u062C\u0627\u062F \u062D\u0644\u0648\u0644 \u0644\u062A\u0633\u0647\u064A\u0644 \u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0628\u064A\u0646 \u0627\u0644\u0628\u0644\u062F\u0627\u0646 \u0648\u062E\u0644\u0642 \u0639\u0627\u0644\u0645 \u0645\u0644\u064A\u0621 \u0628\u0627\u0644\u062A\u0639\u0627\u0648\u0646 \u0648\u0627\u0644\u0645\u062D\u0628\u0629 \u0641\u064A \u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0648\u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629 \u0628\u0645\u0627 \u064A\u062D\u0642\u0642 \u0627\u0639\u0644\u0649 \u0639\u0627\u0626\u062F \u0644\u0644\u062C\u0645\u064A\u0639.",
                    AboutUsPara5: "\u0646\u0633\u0639\u0649 \u0639\u0628\u0631 \u0641\u0631\u064A\u0642 \u0639\u0645\u0644\u0646\u0627 \u0625\u0644\u0649 \u062A\u0633\u0647\u064A\u0644 \u0627\u0644\u062E\u062F\u0645\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0648\u0627\u0644\u0627\u0633\u062A\u062B\u0645\u0627\u0631\u064A\u0629 \u0648\u062A\u0648\u0641\u064A\u0631 \u062C\u0645\u064A\u0639 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0623\u064A \u0639\u0645\u0644\u0629 \u062F\u0648\u0646 \u062C\u0647\u062F \u0623\u0648 \u0639\u0646\u0627\u0621 \u0645\u0639 \u0625\u062A\u0627\u062D\u0629 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0643\u0627\u0641\u0629 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0648\u0627\u0644\u0625\u062C\u0627\u0628\u0627\u062A \u0639\u0644\u0649 \u062C\u0645\u064A\u0639 \u0627\u0644\u0627\u0633\u062A\u0641\u0633\u0627\u0631\u0627\u062A.. \u062D\u0631\u0635\u0627\u064B \u0645\u0646\u0627 \u0639\u0644\u0649 \u062A\u0642\u062F\u064A\u0645 \u0623\u0641\u0636\u0644 \u0627\u0644\u0627\u062E\u062F\u0645\u0627\u062A \u062F\u0627\u0626\u0645\u0627\u064B",
                    news: "\u0627\u0644\u0623\u062E\u0628\u0627\u0631",
                    readMore: "\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0645\u0632\u064A\u062F",
                    change: "\u062A\u0628\u062F\u064A\u0644",
                    PrivacyPolicy: {
                        title: "\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629",
                        introText1: "\u0641\u064A \u0645\u0648\u0642\u0639 (\u0633\u0648\u0631\u064A\u0627 \u0644\u0644\u0635\u0631\u0627\u0641\u0629 )\u060C \u0646\u062F\u0631\u0643 \u0623\u0646 \u062E\u0635\u0648\u0635\u064A\u0629 \u0645\u0639\u0644\u0648\u0645\u0627\u062A\u0643 \u0627\u0644\u0634\u062E\u0635\u064A\u0629 \u0647\u0627\u0645\u0629 \u0644\u0643 \u0648\u0644\u0646\u0627. ",
                        introText2: "\u0641\u064A\u0645\u0627 \u064A\u0644\u064A \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u062D\u0648\u0644 \u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0634\u062E\u0635\u064A\u0629 \u0627\u0644\u062A\u064A \u0646\u062A\u0644\u0642\u0627\u0647\u0627 \u0648\u0646\u0642\u0648\u0645 \u0628\u062C\u0645\u0639\u0647\u0627 \u0639\u0646\u062F \u0632\u064A\u0627\u0631\u0627\u062A https://syria-exchange.com \u060C \u0648\u0643\u064A\u0641 \u0646\u0642\u0648\u0645 \u0628\u062D\u0645\u0627\u064A\u0629 \u0645\u0639\u0644\u0648\u0645\u0627\u062A\u0643 \u0627\u0644\u0634\u062E\u0635\u064A\u0629. \u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0633\u062C\u0644 \u0643\u0645\u0627 \u0647\u0648 \u0627\u0644\u062D\u0627\u0644 \u0645\u0639 \u0645\u0639\u0638\u0645 \u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u0648\u064A\u0628 \u0627\u0644\u0645\u062E\u062A\u0644\u0641\u0629\u060C \u0646\u0642\u0648\u0645 \u0628\u062C\u0645\u0639 \u0648\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0648\u062C\u0648\u062F\u0629 \u0641\u064A \u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0633\u062C\u0644.  \u062A\u0634\u0645\u0644 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0645\u0648\u062C\u0648\u062F\u0629 \u0641\u064A \u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0633\u062C\u0644 \u0639\u0646\u0648\u0627\u0646 \u0628\u0631\u0648\u062A\u0648\u0643\u0648\u0644 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A (IP) \u0627\u0644\u062E\u0627\u0635 \u0628\u0643\u060C \u0648\u0645\u0632\u0648\u062F \u062E\u062F\u0645\u0629 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A (ISP)\u060C \u0648\u0627\u0644\u0645\u062A\u0635\u0641\u062D \u0627\u0644\u0630\u064A \u0627\u0633\u062A\u062E\u062F\u0645\u062A\u0647 \u0644\u0632\u064A\u0627\u0631\u0629 \u0645\u0648\u0642\u0639\u0646\u0627\u060C \u0648\u0627\u0644\u0648\u0642\u062A \u0627\u0644\u0630\u064A \u0642\u0645\u062A \u0641\u064A\u0647 \u0628\u0627\u0644\u0632\u064A\u0627\u0631\u0629\u060C \u0648\u0627\u0644\u0635\u0641\u062D\u0627\u062A \u0627\u0644\u062A\u064A \u0642\u0645\u062A \u0628\u0632\u064A\u0627\u0631\u062A\u0647\u0627 \u0639\u0628\u0631 \u0645\u0648\u0642\u0639\u0646\u0627. ",
                        cookies: {
                            title: "\u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637:",
                            text: "\u0646\u062D\u0646 \u0646\u0633\u062A\u062E\u062F\u0645 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0644\u0646\u0645\u0646\u062D\u0643 \u0623\u0641\u0636\u0644 \u062A\u062C\u0631\u0628\u0629 \u0623\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u0645\u0643\u0646\u0629 \u0639\u0644\u0649 \u0645\u0648\u0642\u0639 \u0628\u0633\u064A\u0637\u060C \u0644\u0645\u0632\u064A\u062F \u0645\u0646 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u062D\u0648\u0644 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u060C \u062A\u0641\u0636\u0644 \u0628\u0632\u064A\u0627\u0631\u0629: http://www.allaboutcookies.org. "
                        },
                        essentialCookies: {
                            title: "\u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629:",
                            text: "\u062A\u0639\u062F \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629 \u0636\u0631\u0648\u0631\u064A\u0629 \u0644\u0643 \u0644\u0644\u062A\u0646\u0642\u0644 \u0648\u0627\u0644\u062A\u0646\u0642\u0644 \u0641\u064A \u062C\u0645\u064A\u0639 \u0623\u0646\u062D\u0627\u0621 \u0627\u0644\u0645\u0648\u0642\u0639\u060C \u0648\u0644\u0627 \u062A\u062E\u0632\u0646 \u0623\u064A \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u064A\u0645\u0643\u0646 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647\u0627 \u0644\u0623\u063A\u0631\u0627\u0636 \u0627\u0644\u062F\u0639\u0627\u064A\u0629\u060C \u0628\u062F\u0648\u0646 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629 \u0644\u0646 \u064A\u0639\u0645\u0644 \u0645\u0648\u0642\u0639\u0646\u0627 \u0628\u0634\u0643\u0644 \u0635\u062D\u064A\u062D."
                        },
                        customCookies: {
                            title: "\u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0627\u0644\u0645\u062E\u0635\u0635\u0629:",
                            text: " \u062A\u062E\u0632\u0646 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0647\u0630\u0647 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u060C \u0645\u062B\u0644 \u062A\u0641\u0636\u064A\u0644\u0627\u062A\u0643 \u0627\u0644\u0634\u062E\u0635\u064A\u0629 \u060C \u0648\u062A\u0633\u062A\u062E\u062F\u0645\u0647\u0627 \u0644\u062A\u062E\u0635\u064A\u0635 \u062A\u062C\u0631\u0628\u0629 \u0641\u0631\u064A\u062F\u0629 \u0644\u0643. \u0642\u062F \u064A\u0634\u0645\u0644 \u0630\u0644\u0643 \u0639\u0631\u0636 \u0646\u0627\u0641\u0630\u0629 \u0645\u0646\u0628\u062B\u0642\u0629 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u0642\u0637 \u0641\u064A \u0632\u064A\u0627\u0631\u062A\u0643 \u060C \u0623\u0648 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644\u0627\u062A \u0627\u0644\u0644\u063A\u0629 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0643 \u060C \u0623\u0648 \u0627\u0644\u0633\u0645\u0627\u062D \u0644\u0643 \u0628\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 \u0625\u0644\u0649 \u0628\u0639\u0636 \u0645\u064A\u0632\u0627\u062A\u0646\u0627. "
                        },
                        analyticalCookies: {
                            title: "\u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0641\u064A Analytics:",
                            text: "\u062A\u0644\u062A\u0642\u0637 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0645\u0646 Analytics \u0628\u064A\u0627\u0646\u0627\u062A \u0645\u062C\u0647\u0648\u0644\u0629 \u0627\u0644\u0645\u0635\u062F\u0631 \u062D\u062A\u0649 \u0646\u062A\u0645\u0643\u0646 \u0645\u0646 \u0631\u0624\u064A\u0629 \u0627\u0644\u0627\u062A\u062C\u0627\u0647\u0627\u062A \u0648\u062A\u062D\u0633\u064A\u0646 \u062A\u062C\u0631\u0628\u0629 \u0645\u0648\u0642\u0639\u0646\u0627 \u0639\u0644\u0649 \u0627\u0644\u0648\u064A\u0628. \u0647\u0630\u0647 \u062A\u062A\u064A\u062D \u0644\u0646\u0627 \u0627\u062E\u062A\u0628\u0627\u0631 \u062A\u0635\u0645\u064A\u0645\u0627\u062A \u0645\u062E\u062A\u0644\u0641\u0629 \u060C\u0648\u062A\u0633\u0627\u0639\u062F\u0646\u0627 \u0639\u0644\u0649 \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0643\u0633\u0631 \u0625\u0630\u0627 \u0643\u0627\u0646 \u062C\u0632\u0621 \u0645\u0646 \u0645\u0648\u0642\u0639\u0646\u0627 \u0644\u0627 \u064A\u0639\u0645\u0644."
                        },
                        advertisingCookies: {
                            title: "\u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0644\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A:",
                            terms: [
                                "\u0642\u062F \u064A\u0633\u062A\u062E\u062F\u0645 \u0628\u0639\u0636 \u0627\u0644\u0645\u0639\u0644\u0646\u064A\u0646 \u0645\u0646 \u0627\u0644\u062C\u0647\u0627\u062A \u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0623\u0648 \u0625\u0634\u0627\u0631\u0627\u062A \u0627\u0644\u0648\u064A\u0628 \u0639\u0646\u062F \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0639\u0644\u0649 \u0645\u0648\u0642\u0639\u0646\u0627. \u0633\u064A\u0642\u0648\u0645 \u0647\u0624\u0644\u0627\u0621 \u0628\u0625\u0631\u0633\u0627\u0644 \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0625\u0644\u0649 \u0647\u0624\u0644\u0627\u0621 \u0627\u0644\u0645\u0639\u0644\u0646\u064A\u0646 (\u0645\u062B\u0644 Google \u0645\u0646 \u062E\u0644\u0627\u0644 \u0628\u0631\u0646\u0627\u0645\u062C Google AdSense) \u0628\u0645\u0627 \u0641\u064A \u0630\u0644\u0643 \u0639\u0646\u0648\u0627\u0646 IP \u0627\u0644\u062E\u0627\u0635 \u0628\u0643 \u060C \u0648\u0645\u0632\u0648\u062F \u062E\u062F\u0645\u0629 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A \u060C \u0648\u0627\u0644\u0645\u062A\u0635\u0641\u062D \u0627\u0644\u0630\u064A \u0627\u0633\u062A\u062E\u062F\u0645\u062A\u0647 \u0644\u0632\u064A\u0627\u0631\u0629 \u0645\u0648\u0642\u0639\u0646\u0627 \u060C \u0648\u0641\u064A \u0628\u0639\u0636 \u0627\u0644\u062D\u0627\u0644\u0627\u062A \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u062D\u0648\u0644 \u0645\u0627 \u0625\u0630\u0627 \u0643\u0646\u062A \u0642\u062F \u0642\u0645\u062A \u0628\u062A\u062B\u0628\u064A\u062A Flash.",
                                " \u064A\u0633\u062A\u062E\u062F\u0645 \u0645\u0648\u0631\u062F\u0648 \u0627\u0644\u062C\u0647\u0627\u062A \u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629\u060C \u0628\u0645\u0646 \u0641\u064A\u0647\u0645 Google\u060C \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0631\u062A\u0628\u0627\u0637 \u0644\u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0628\u0646\u0627\u0621\u064B \u0639\u0644\u0649 \u0632\u064A\u0627\u0631\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0633\u0627\u0628\u0642\u0629 \u0644\u0645\u0648\u0642\u0639\u0646\u0627 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0644\u0645\u0648\u0627\u0642\u0639 \u0623\u062E\u0631\u0649 \u0639\u0644\u0649 \u0627\u0644\u0648\u064A\u0628.",
                                "\u0633\u062A\u062A\u0645\u0643\u0651\u0646 Google \u0648\u0634\u0631\u0643\u0627\u0624\u0647\u0627\u060C \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0644\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A\u060C \u0645\u0646 \u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646 \u0644\u062F\u064A\u0643 \u0627\u0633\u062A\u0646\u0627\u062F\u064B\u0627 \u0625\u0644\u0649 \u0632\u064A\u0627\u0631\u0627\u062A\u0647\u0645 \u0644\u0645\u0648\u0642\u0639\u0646\u0627 \u0648/\u0623\u0648 \u0645\u0648\u0627\u0642\u0639 \u0623\u062E\u0631\u0649 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A.",
                                "\u064A\u0645\u0643\u0646 \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646 \u062A\u0639\u0637\u064A\u0644 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u062E\u0635\u0635\u0629 \u0639\u0646 \u0637\u0631\u064A\u0642 \u0627\u0644\u0627\u0646\u062A\u0642\u0627\u0644 \u0625\u0644\u0649 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A.", 
                            ]
                        },
                        outroText1: " \u0625\u0630\u0627 \u0644\u0645 \u064A\u062A\u0645 \u0627\u062E\u062A\u064A\u0627\u0631 \u062A\u0639\u0637\u064A\u0644 \u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u0623\u0637\u0631\u0627\u0641 \u0627\u0644\u062B\u0627\u0644\u062B\u0629\u060C \u0641\u0642\u062F \u064A\u062A\u0645 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0631\u062A\u0628\u0627\u0637 \u0645\u0648\u0631\u062F\u064A \u0623\u0648 \u0634\u0628\u0643\u0627\u062A \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u0623\u0637\u0631\u0627\u0641 \u0627\u0644\u062B\u0627\u0644\u062B\u0629 \u0627\u0644\u0623\u062E\u0631\u0649 \u0623\u064A\u0636\u064B\u0627 \u0644\u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0641\u064A \u0645\u0648\u0642\u0639\u0646\u0627. \u064A\u0633\u062A\u062E\u062F\u0645 \u0647\u0630\u0627 \u0628\u0634\u0643\u0644 \u0639\u0627\u0645 \u0644\u0623\u063A\u0631\u0627\u0636 \u0627\u0644\u0627\u0633\u062A\u0647\u062F\u0627\u0641 \u0627\u0644\u062C\u063A\u0631\u0627\u0641\u064A \u0639\u0644\u0649 \u0633\u0628\u064A\u0644 \u0627\u0644\u0645\u062B\u0627\u0644 (\u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A SEO \u0641\u064A \u0623\u0644\u0645\u0627\u0646\u064A\u0627 \u0644\u0634\u062E\u0635 \u0645\u0627 \u0641\u064A \u0623\u0644\u0645\u0627\u0646\u064A\u0627 ) \u0623\u0648 \u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0645\u0639\u064A\u0646\u0629 \u0628\u0646\u0627\u0621\u064B \u0639\u0644\u0649 \u0645\u0648\u0627\u0642\u0639 \u0645\u062D\u062F\u062F\u0629 \u062A\u0645\u062A\u0632\u064A\u0627\u0631\u062A\u0647\u0627 (\u0645\u062B\u0644 \u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A \u0644\u0634\u062E\u0635 \u064A\u0631\u062A\u0627\u062F \u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A).",
                        outroText2: "\u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0644\u0627\u0633\u062A\u0645\u0631\u0627\u0631 \u0641\u064A \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u0648\u0642\u0639\u0646\u0627 \u060C \u0641\u0625\u0646\u0643 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0648\u0636\u0639 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0639\u0644\u0649 \u062C\u0647\u0627\u0632\u0643. \u064A\u0645\u0643\u0646\u0643 \u0627\u062E\u062A\u064A\u0627\u0631 \u062A\u0639\u0637\u064A\u0644 \u0623\u0648 \u0625\u064A\u0642\u0627\u0641 \u062A\u0634\u063A\u064A\u0644 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0644\u0627\u0631\u062A\u0628\u0627\u0637 \u0623\u0648 \u0645\u0644\u0641\u0627\u062A \u062A\u0639\u0631\u064A\u0641 \u0627\u0631\u062A\u0628\u0627\u0637 \u0627\u0644\u0637\u0631\u0641 \u0627\u0644\u062B\u0627\u0644\u062B \u0628\u0634\u0643\u0644 \u0627\u0646\u062A\u0642\u0627\u0626\u064A \u0641\u064A \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u062A\u0635\u0641\u062D \u0627\u0644\u062E\u0627\u0635 \u0628\u0643. \u0648\u0645\u0639 \u0630\u0644\u0643 \u060C \u064A\u0645\u0643\u0646 \u0623\u0646 \u064A\u0624\u062B\u0631 \u0647\u0630\u0627 \u0639\u0644\u0649 \u0643\u064A\u0641\u064A\u0629 \u062A\u0641\u0627\u0639\u0644\u0643 \u0645\u0639 \u0645\u0648\u0642\u0639\u0646\u0627 \u0648\u0643\u0630\u0644\u0643 \u0645\u0639 \u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u0648\u064A\u0628 \u0627\u0644\u0623\u062E\u0631\u0649. \u0627\u0630\u0627 \u0643\u0627\u0646 \u0644\u062F\u064A\u0643 \u0627\u0649 \u0633\u0624\u0627\u0644 \u0627\u0648 \u0643\u0627\u0646 \u0647\u0646\u0627 \u0627\u0649 \u0645\u0634\u0643\u0644\u0629 \u0641\u0649  \u0633\u064A\u0627\u0633\u0629 \u0623\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0646\u0627 \u0627\u0644\u0631\u062C\u0627\u0621 \u0627\u0644\u0645\u0631\u0627\u0633\u0644\u0629 \u0639 \u0645\u0646 \u062E\u0644\u0627\u0644 \u0635\u0641\u062D\u0629 \u0627\u0644\u0623\u062A\u0635\u0627\u0644 \u0628\u0646\u0627 ",
                        emailContact: " \u0627\u0648 \u0639\u0628\u0631 \u0627\u0644\u0627\u064A\u0645\u064A\u0644"
                    },
                    UserAgreement: {
                        title: "\u0627\u062A\u0641\u0627\u0642\u064A\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645",
                        introText: "\u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0643 \u0644\u0645\u0648\u0642\u0639 \u0633\u0648\u0631\u064A\u0627 \u0644\u0644\u0635\u0631\u0627\u0641\u0629 \u0641\u0625\u0646\u0643 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0627\u0644\u0627\u0644\u062A\u0632\u0627\u0645 \u0628\u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u0623\u062D\u0643\u0627\u0645 \u0627\u0644\u0645\u0646\u0635\u0648\u0635 \u0639\u0644\u064A\u0647\u0627 \u0644\u0630\u0627 \u064A\u062C\u0628 \u0639\u0644\u064A\u0643 \u0627\u0644\u0627\u0637\u0644\u0627\u0639 \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0623\u062D\u0643\u0627\u0645 \u0648\u0623\u062E\u062F\u0647\u0627 \u0628\u0639\u064A\u0646 \u0627\u0644\u0627\u0639\u062A\u0628\u0627\u0631:",
                        condition1: {
                            title: "\u0642\u0628\u0648\u0644 \u0627\u0644\u0627\u062A\u0641\u0627\u0642\u064A\u0629",
                            terms: [
                                "\u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0643 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639\u060C \u0641\u0647\u0630\u0627 \u064A\u0634\u064A\u0631 \u0627\u0644\u0649 \u0645\u0648\u0627\u0641\u0642\u062A\u0643 \u0627\u0644\u0643\u0627\u0645\u0644\u0629 \u0639\u0644\u0649 \u0642\u0628\u0648\u0644 \u062C\u0645\u064A\u0639 \u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u0623\u062D\u0643\u0627\u0645 \u0627\u0644\u0648\u0627\u0631\u062F\u0629 \u0647\u0646\u0627.",
                                "\u064A\u062C\u0628 \u0639\u062F\u0645 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639 \u0641\u064A \u062D\u0627\u0644 \u0643\u0646\u062A \u063A\u064A\u0631 \u0645\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0623\u064A \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u0623\u062D\u0643\u0627\u0645 \u0627\u0644\u0642\u064A\u0627\u0633\u064A\u0629.",
                                "\u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u0623\u062D\u0643\u0627\u0645 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0646\u0627 \u0641\u064A \u0646\u0645\u0648\u0630\u062C \u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u0623\u062D\u0643\u0627\u0645 \u0648\u0646\u0645\u0648\u0630\u062C \u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629.",
                                "\u064A\u0645\u0646\u0639 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639 \u0644\u0645\u0646 \u062A\u0642\u0644 \u0623\u0639\u0645\u0627\u0631\u0647\u0645 \u0639\u0646 18 \u0639\u0627\u0645.", 
                            ]
                        },
                        condition2: {
                            title: "\u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0644\u0643\u064A\u0629 \u0627\u0644\u0641\u0631\u062F\u064A\u0629",
                            terms: [
                                "\u062C\u0645\u064A\u0639 \u0627\u0644\u0639\u0644\u0627\u0645\u0627\u062A \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629 \u0627\u0644\u062A\u064A \u062A\u0639\u0631\u0636 \u0639\u0644\u0649 \u0647\u0627 \u0627\u0644\u0645\u0648\u0642\u0639 \u0647\u064A \u0645\u0644\u0643 \u062E\u0627\u0635 \u0644\u0647. \u0648\u0623\u064A\u0636\u0627 \u0643\u0627\u0641\u0629 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0645\u0639\u0631\u0648\u0636 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639 \u0645\u0646 \u0635\u0648\u0631 \u0648\u0645\u0648\u0633\u064A\u0642\u0649 \u0648\u0631\u0633\u0648\u0645 \u0648\u063A\u064A\u0631\u0647\u0627 \u0647\u064A \u0645\u0644\u0643 \u062D\u0635\u0631\u064A \u0644\u0644\u0645\u0648\u0642\u0639 \u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647\u0627 \u0642\u0628\u0644 \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0627\u0630\u0646 \u0645\u0646 \u0645\u0627\u0644\u0643 \u0627\u0644\u0645\u0648\u0642\u0639.",
                                "\u0646\u062D\u0646 \u0646\u0642\u062F\u0645 \u0644\u0643 \u0635\u0644\u0627\u062D\u064A\u0629 \u062A\u0635\u0641\u062D \u0627\u0644\u0645\u0648\u0642\u0639 \u0648\u0627\u0639\u0627\u062F\u0629 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0628\u0639\u0636 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0644\u0623\u063A\u0631\u0627\u0636 \u0634\u062E\u0635\u064A\u0629 \u0641\u0642\u0637 \u0648\u0644\u0627 \u064A\u062C\u0648\u0632 \u0628\u0623\u064A \u0634\u0643\u0644 \u0645\u0646 \u0627\u0644\u0623\u0634\u0643\u0627\u0644 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0645\u0648\u0642\u0639 \u0644\u0623\u063A\u0631\u0627\u0636 \u062A\u062C\u0627\u0631\u064A\u0629 \u0623\u0648 \u062F\u0645\u062C \u0627\u0644\u0645\u0648\u0642\u0639 \u0645\u0639 \u0645\u0648\u0642\u0639 \u0623\u062E\u0631 \u0625\u0644\u0627 \u0628\u0639\u062F \u0627\u0644\u0627\u062A\u0641\u0627\u0642 \u0645\u0639\u0646\u0627 \u0648\u0639\u0642\u062F \u0634\u0631\u0627\u0643\u0629 \u0645\u0639\u0646\u0627 \u0648\u0641\u064A \u062D\u0627\u0644 \u0642\u064A\u0627\u0645 \u0623\u062D\u062F \u0627\u0644\u0623\u0634\u062E\u0627\u0635 \u0623\u0648 \u0627\u0644\u0645\u0648\u0627\u0642\u0639 \u0628\u0647\u0627 \u0641\u0627\u0646\u0647 \u0633\u064A\u062A\u0639\u0631\u0636 \u0644\u0644\u0645\u0633\u0627\u0621\u0644\u0629 \u0627\u0644\u0642\u0627\u0646\u0648\u0646\u064A\u0629.", 
                            ]
                        },
                        condition3: {
                            title: "\u0627\u0644\u0642\u064A\u0648\u062F",
                            text: "\u0641\u064A \u062D\u0627\u0644 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0643 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639 \u064A\u0645\u0646\u0639 \u0639\u0644\u064A\u0643 \u0623\u0646 \u062A\u0642\u0648\u0645 \u0628\u0645\u0627 \u064A\u0644\u064A:",
                            terms: [
                                "\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0645\u0648\u0642\u0639 \u0628\u0637\u0631\u064A\u0642\u0629 \u063A\u064A\u0631 \u0642\u0627\u0646\u0648\u0646\u064A\u0629 \u0623\u0648 \u0645\u062E\u0627\u0644\u0641\u0629 \u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629.",
                                "\u0627\u0644\u0642\u064A\u0627\u0645 \u0628\u0623\u064A \u0633\u0644\u0648\u0643 \u0645\u0646 \u0634\u0623\u0646\u0647 \u062A\u0639\u0637\u064A\u0644 \u0623\u0648 \u0627\u062A\u0644\u0627\u0641 \u0623\u0648 \u0627\u0644\u062D\u0627\u0642 \u0627\u0644\u0636\u0631\u0631 \u0628\u0627\u0644\u0645\u0648\u0642\u0639 \u0648\u0627\u0644\u062A\u062F\u0627\u062E\u0644 \u0645\u0639 \u0627\u0644\u0639\u0645\u0644 \u0623\u0648 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u062E\u0627\u0635 \u0644\u0644\u0645\u0648\u0642\u0639 \u0623\u0648 \u0645\u0639 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0623\u064A \u0634\u062E\u0635 \u0622\u062E\u0631.",
                                "\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0647\u0627 \u0627\u0644\u0645\u0648\u0642\u0639 \u0644\u063A\u0631\u0636 \u0627\u0644\u0627\u0639\u0644\u0627\u0646 \u0623\u0648 \u0627\u0644\u062A\u0633\u0648\u064A\u0642 \u0623\u0648 \u0627\u0644\u062F\u0639\u0627\u064A\u0629 \u062F\u0648\u0646 \u0623\u062E \u0627\u0630\u0646 \u0645\u0633\u0628\u0642 \u0645\u0646 \u0645\u0627\u0644\u0643 \u0627\u0644\u0645\u0648\u0642\u0639.",
                                "\u0646\u0634\u0631 \u0627\u0644\u0643\u0631\u0627\u0647\u064A\u0629 \u0623\u0648 \u0627\u0644\u0639\u0646\u0635\u0631\u064A\u0629 \u0623\u0648 \u0643\u0644\u0627\u0645 \u0628\u0630\u064A\u0621 \u0623\u0648 \u0627\u0644\u062A\u0634\u0647\u064A\u0631 \u0628\u0634\u062E\u0635 \u0623\u0648 \u0628\u0645\u0648\u0642\u0639 \u062D\u064A\u062B \u0647\u0630\u0627 \u064A\u0639\u0631\u0636\u0643 \u0644\u0644\u0645\u0633\u0627\u0621\u0644\u0629 \u0627\u0644\u0642\u0627\u0646\u0648\u0646\u064A\u0629.",
                                "\u0625\u0632\u0627\u0644\u0629 \u0627\u062D\u062F\u0649 \u0627\u0644\u0627\u0634\u0639\u0627\u0631\u0627\u062A \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u062D\u0642\u0648\u0642 \u0627\u0644\u0637\u0628\u0639 \u0648\u0627\u0644\u0646\u0634\u0631 \u0623\u0648 \u0623\u064A \u0627\u0634\u0639\u0627\u0631\u0627\u062A \u0623\u062E\u0631\u0649 \u062E\u0627\u0635\u0629 \u0628\u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0644\u0643\u064A\u0629 \u0627\u0644\u0641\u0643\u0631\u064A\u0629 \u0645\u0646 \u0627\u0644\u0645\u0648\u0642\u0639 \u0623\u0648 \u0628\u0645\u062D\u062A\u0648\u0649 \u0645\u062A\u0627\u062D \u0639\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639 \u0623\u0648 \u0639\u0628\u0631\u0647. \u0627\u0646 \u0642\u064A\u0627\u0645\u0643 \u0628\u0623\u064A \u0645\u0646 \u0627\u0644\u0646\u0634\u0627\u0637\u0627\u062A \u0627\u0644\u0633\u0627\u0628\u0642\u0629 \u0627\u0644\u0645\u062E\u0627\u0644\u0641\u0629 \u0644\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u0645\u0648\u0642\u0639 \u064A\u0639\u0631\u0636\u0643 \u0644\u0644\u0645\u0633\u0627\u0626\u0644 \u0627\u0644\u0642\u0627\u0646\u0648\u0646\u064A\u0629.", 
                            ]
                        },
                        condition4: {
                            title: "\u0627\u062E\u0644\u0627\u0621 \u0627\u0644\u0645\u0633\u0624\u0648\u0644\u064A\u0629",
                            text: "\u0627\u0646 \u0648\u0635\u0648\u0644\u0643 \u0627\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639 \u0648\u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0643 \u0644\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u062E\u0627\u0635 \u0628\u0647 \u064A\u0642\u0639 \u0639\u0644\u0649 \u0645\u0633\u0624\u0648\u0644\u064A\u0643 \u0627\u0644\u062E\u0627\u0635\u0629. \u062D\u064A\u062B \u0623\u0646 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062A\u064A \u0646\u0642\u062F\u0645\u0647\u0627 \u0647\u064A \u0644\u0623\u063A\u0631\u0627\u0636 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0639\u0627\u0645\u0629 \u0641\u0642\u0637. \u0648\u064A\u062A\u0645 \u062A\u0648\u0641\u064A\u0631 \u062C\u0645\u064A\u0639 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0639\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639 \u0628\u062D\u0633\u0646 \u0646\u064A\u0629. \u0648\u0645\u0639 \u0630\u0644\u0643\u060C \u0641\u0625\u0646\u0646\u0627 \u0644\u0627 \u0646\u0642\u062F\u0645 \u0623\u064A \u062A\u0639\u0647\u062F \u0623\u0648 \u0636\u0645\u0627\u0646 \u0645\u0646 \u0623\u064A \u0646\u0648\u0639\u060C \u0635\u0631\u064A\u062D\u064B\u0627 \u0623\u0648 \u0636\u0645\u0646\u064A\u064B\u0627\u060C \u0641\u064A\u0645\u0627 \u064A\u062A\u0639\u0644\u0642 \u0628\u062F\u0642\u0629 \u0623\u0648 \u0643\u0641\u0627\u064A\u0629 \u0623\u0648 \u0635\u062D\u0629 \u0623\u0648 \u0645\u0648\u062B\u0648\u0642\u064A\u0629 \u0623\u0648 \u062A\u0648\u0641\u0631 \u0623\u0648 \u0627\u0643\u062A\u0645\u0627\u0644 \u0623\u064A \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0639\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639."
                        },
                        condition5: {
                            title: "\u062E\u0635\u0648\u0635\u064A\u062A\u0643",
                            text: "\u0627\u0644\u0631\u062C\u0627\u0621 \u0642\u0631\u0627\u0621\u0629 \u0633\u064A\u0627\u0633\u064A\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 \u0648\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u062E\u0627\u0635 \u0628\u0643 \u062D\u0642 \u0641\u0631\u062F\u064A \u0628\u0634\u0631\u0637 \u0627\u0646 \u0644\u0627 \u064A\u0646\u062A\u0647\u0643 \u0627\u0644\u062D\u0642\u0648\u0642 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0627\u0644\u0645\u0648\u0642\u0639. \u0648\u064A\u0645\u062A\u0644\u0643 \u0627\u0644\u0645\u0648\u0642\u0639 \u0623\u064A\u0636\u0627\u064B \u0635\u0644\u0627\u062D\u064A\u0629 \u0644\u0627\u0632\u0627\u0644\u0629 \u0623\u064A \u0645\u062D\u062A\u0648\u0649 \u062E\u0627\u0635 \u0628\u0643 \u062F\u0648\u0646 \u0633\u0627\u0628\u0642 \u0627\u0646\u0630\u0627\u0631."
                        }
                    }
                }
            }
        }
    }
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (i18n)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    openGraph: {
        type: "website",
        locale: "ar_AR",
        url: "https://syria-exchange.com",
        site_name: "syria-exchange.com",
        images: [
            {
                url: "https://syria-exchange.com/syria-exchange-share.jpg",
                width: 800,
                height: 600,
                alt: "syria-exchange",
                type: "image/jpg"
            }, 
        ]
    },
    twitter: {
        site: "@syria-exchange.com",
        cardType: "summary_large_image"
    }
});


/***/ }),

/***/ 8484:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5941);
/* harmony import */ var react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6593);
/* harmony import */ var react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7488);
/* harmony import */ var react_bootstrap_SSRProvider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4932);
/* harmony import */ var react_bootstrap_SSRProvider__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_SSRProvider__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _next_seo_config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(666);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_1__, _lib_i18n__WEBPACK_IMPORTED_MODULE_3__]);
([swr__WEBPACK_IMPORTED_MODULE_1__, _lib_i18n__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














function MyApp({ Component , pageProps  }) {
    const { i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    if (false) {}
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swr__WEBPACK_IMPORTED_MODULE_1__.SWRConfig, {
        value: {
            fetcher: (r)=>fetch(`https://syria-exchange.com/panel/v1/api${r}`).then((res)=>res.json()
                )
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_SSRProvider__WEBPACK_IMPORTED_MODULE_4___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_5__.DefaultSeo, {
                    ..._next_seo_config__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                    additionalMetaTags: [
                        {
                            name: "facebook-domain-verification",
                            content: "iytkd3zpbcf8sc22whobbk2tze4v6v"
                        }, 
                    ],
                    additionalLinkTags: [
                        {
                            rel: "icon",
                            type: "image/svg+xml",
                            href: "/logo.svg"
                        },
                        {
                            rel: "icon",
                            type: "image/png",
                            href: "/favicon-32x32.png",
                            sizes: "32x32"
                        },
                        {
                            rel: "icon",
                            type: "image/png",
                            sizes: "16x16",
                            href: "/favicon-16x16.png"
                        },
                        {
                            rel: "stylesheet",
                            href: "/assets/bootstrap/css/bootstrap.min.css"
                        },
                        {
                            rel: "manifest",
                            href: "/manifest.json"
                        }, 
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6593:
/***/ (() => {



/***/ }),

/***/ 6071:
/***/ ((module) => {

"use strict";
module.exports = require("i18next-browser-languagedetector");

/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 4932:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/SSRProvider");

/***/ }),

/***/ 9709:
/***/ ((module) => {

"use strict";
module.exports = require("react-i18next");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

"use strict";
module.exports = import("swr");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8484));
module.exports = __webpack_exports__;

})();