"use strict";
(() => {
var exports = {};
exports.id = 459;
exports.ids = [459];
exports.modules = {

/***/ 9582:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(972);
/* harmony import */ var react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _skeletons_CurrencyRowSkeleton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8569);






const InterCoinCER = ({ title , border , color , items , lastUpdated  })=>{
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const { 0: seeMore , 1: setSeeMore  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const ToastRadius = i18n.dir() === "ltr" ? "toastRadiusEN" : "toastRadiusAr";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "cer",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "cerNav",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: "justify-content-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: "d-flex",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/logo.svg",
                                    alt: "Syria Exchange",
                                    className: "img"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    style: {
                                        color: color
                                    },
                                    children: i18n.dir() === "ltr" ? `${title}
              ${t("description.exchangeRate")}` : `${t("description.exchangeRate")}
              ${title}`
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            style: {
                                margin: "0 16px"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("time", {
                                className: "date",
                                dateTime: lastUpdated,
                                children: lastUpdated
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "cerToast TurkishCer",
                id: seeMore ? "TurkishCerShow" : " ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "cerToastFirstRow",
                        style: {
                            backgroundColor: border,
                            color: color
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader grid-col-span-2",
                                children: t("description.headerCERCurr")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader grid-col-span-2",
                                children: t("description.headerCERCurrSell")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader grid-col-span-2",
                                children: t("description.headerCERCurr")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader grid-col-span-2",
                                children: t("description.headerCERCurrSell")
                            })
                        ]
                    }),
                    items ? items?.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: `grid-col-span-4 ${ToastRadius}`,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2___default().Body), {
                                className: "toastBody",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: " toastFirstFragment grid-col-span-2 interCointoastFirstFragment",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: `/currIcons/${item.curr_abbreviation}.png`,
                                                alt: item.curr_abbreviation,
                                                className: "toastFlag interCoinsToastFlag"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        children: i18n.dir() === "ltr" ? item.curr_en_name.toUpperCase() : item.curr_ar_name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                        children: item.curr_abbreviation
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "toastArrowDiv",
                                                children: [
                                                    item.curr_status < "0" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__.RiArrowDownSLine, {
                                                        className: "toastArrowDown"
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__.RiArrowUpSLine, {
                                                        className: "toastArrowUp"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                        className: item.curr_status < "0" ? "font-number red" : "font-number green",
                                                        children: item.curr_status
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "toastPara font-number grid-col-span-2 interCoinToastPara",
                                        children: item.curr_sell
                                    })
                                ]
                            })
                        }, item.id)
                    ) : Array.from({
                        length: 12
                    }).map((_, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_skeletons_CurrencyRowSkeleton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}, index)
                    )
                ]
            }),
            !seeMore && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "seeMore",
                id: "TrukishSeeMore",
                onClick: ()=>setSeeMore(true)
                ,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    children: t("description.headerCERSeeMore")
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InterCoinCER);


/***/ }),

/***/ 8440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(972);
/* harmony import */ var react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_4__);





const InterGoldPrices = ({ title , color , border , abbriviation  })=>{
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const { 0: interGold , 1: setInterGold  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        async function getInterGold() {
            const request = fetch("https://syria-exchange.com/panel/v1/api/international-gold.php");
            const response = await request;
            const parsed = await response.json();
            setInterGold(parsed);
        }
        getInterGold();
    }, []);
    if (interGold === undefined) {
        return null;
    }
    const GetGoldPrices = interGold.gold_prices.map((item)=>{
        for (let [key, value] of Object.entries(item)){
            return [
                key,
                value
            ];
        }
        return GetGoldPrices;
    });
    let goldPrices = GetGoldPrices.filter((item)=>item[0] === abbriviation
    );
    let toastEnClass = i18n.dir() === "ltr" ? "toastEN" : "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "cer",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "cerNav",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/gold.png",
                                alt: "Syria Exchange",
                                className: "img"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                style: {
                                    color: color
                                },
                                children: i18n.dir() === "ltr" ? `${title}
              ${t("description.GoldRate")}` : `${t("description.GoldRate")}
              ${title}`
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "goldPricesToast",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "cerToastFirstRow",
                        style: {
                            backgroundColor: border
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader grid-col-span-2",
                                children: t("description.MetalType")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader",
                                children: abbriviation
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader",
                                children: t("description.USD")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader grid-col-span-2",
                                children: t("description.MetalType")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader",
                                children: abbriviation
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "cerToastHeader",
                                children: t("description.USD")
                            })
                        ]
                    }),
                    goldPrices.length !== 0 ? goldPrices[0][1].map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: `grid-col-span-4 ${toastEnClass}`,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_2___default().Body), {
                                className: "toastBody",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: " toastFirstFragment grid-col-span-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/gold.png",
                                                alt: "Syria Exchange",
                                                className: "img"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: i18n.dir() === "rtl" ? item.gold_name : item.gold_name_en
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "toastArrowDiv",
                                                children: [
                                                    item.gold_status < "0" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__.RiArrowDownSLine, {
                                                        className: "toastArrowDown"
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__.RiArrowUpSLine, {
                                                        className: "toastArrowUp"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                        className: item.gold_status < "0" ? "font-number red" : "font-number green",
                                                        children: item.gold_status
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "toastPara font-number",
                                        children: item.gold_any
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "toastPara font-number",
                                        children: item.gold_usd
                                    })
                                ]
                            })
                        }, index)
                    ) : ""
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InterGoldPrices);


/***/ }),

/***/ 8984:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_currency_converter_CurrencyConverter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1690);
/* harmony import */ var _components_img_fig_IMGFig1__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1473);
/* harmony import */ var _components_img_fig_IMGFig2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6120);
/* harmony import */ var _components_turkish_currency_exchange_rate_InterCoinCER__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9582);
/* harmony import */ var _components_turkish_gold_prices_InterGoldPrices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8440);
/* harmony import */ var _components_footer_Footer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4620);
/* harmony import */ var _components_Header111__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7226);
/* harmony import */ var _components_ScrollToTop__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3837);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_currency_converter_CurrencyConverter__WEBPACK_IMPORTED_MODULE_5__, _components_img_fig_IMGFig1__WEBPACK_IMPORTED_MODULE_6__, _components_img_fig_IMGFig2__WEBPACK_IMPORTED_MODULE_7__]);
([_components_currency_converter_CurrencyConverter__WEBPACK_IMPORTED_MODULE_5__, _components_img_fig_IMGFig1__WEBPACK_IMPORTED_MODULE_6__, _components_img_fig_IMGFig2__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const CURRENCY_ABBRE_TO_NAME = {
    USD: [
        "USA Dollar",
        "\u062F\u0648\u0644\u0627\u0631 \u0627\u0645\u0631\u064A\u0643\u064A"
    ],
    AED: [
        "Emirati Dirham",
        "\u062F\u0631\u0647\u0645 \u0625\u0645\u0627\u0631\u0627\u062A\u064A"
    ],
    AUD: [
        "Australian Dollar",
        "\u062F\u0648\u0644\u0627\u0631\u0627\u0633\u062A\u0631\u0627\u0644\u064A"
    ],
    BHD: [
        "Bahraini Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0628\u062D\u0631\u064A\u0646\u064A"
    ],
    BRL: [
        "Brazilian Real",
        "\u0631\u064A\u0627\u0644 \u0628\u0631\u0627\u0632\u064A\u0644\u064A"
    ],
    CAD: [
        "Canadian Dollar",
        "\u062F\u0648\u0644\u0627\u0631 \u0643\u0646\u062F\u064A"
    ],
    CHF: [
        "Swiss Franc",
        "\u0641\u0631\u0646\u0643 \u0633\u0648\u064A\u0633\u0631\u064A"
    ],
    CNY: [
        "Chinese Renminbi",
        "\u064A\u0648\u0627\u0646 \u0635\u064A\u0646\u064A"
    ],
    COP: [
        "Colombian Pesos",
        "\u0628\u064A\u0632\u0648 \u0643\u0648\u0644\u0648\u0645\u0628\u064A"
    ],
    DJF: [
        "Djibouti Franc",
        "\u0641\u0631\u0646\u0643 \u062C\u064A\u0628\u0648\u062A\u064A"
    ],
    DKK: [
        "Danish Krone",
        "\u0643\u0631\u0648\u0646\u0629 \u062F\u0646\u0645\u0627\u0631\u0643\u064A\u0629"
    ],
    DZD: [
        "Algerian Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u062C\u0632\u0627\u0626\u0631\u064A"
    ],
    EGP: [
        "Egyptian Pound",
        "\u062C\u0646\u064A\u0647 \u0645\u0635\u0631\u064A"
    ],
    EUR: [
        "Euro",
        "\u064A\u0648\u0631\u0648"
    ],
    GBP: [
        "Pound Sterling",
        "\u062C\u0646\u064A\u0647 \u0625\u0633\u062A\u0631\u0644\u064A\u0646\u064A"
    ],
    IDR: [
        "Indonesian Rupiah",
        "\u0631\u0648\u0628\u064A\u0629 \u0625\u0646\u062F\u0648\u0646\u064A\u0633\u064A\u0629"
    ],
    IQD: [
        "Iraqi Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0639\u0631\u0627\u0642\u064A "
    ],
    IRR: [
        "Iranian Rial",
        "\u0631\u064A\u0627\u0644 \u0625\u064A\u0631\u0627\u0646\u064A"
    ],
    JOD: [
        "Jordanian Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0623\u0631\u062F\u0646\u064A"
    ],
    JPY: [
        "Japanese Yen",
        "\u064A\u0646 \u064A\u0627\u0628\u0627\u0646\u064A"
    ],
    KWD: [
        "Kuwaiti Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0643\u0648\u064A\u062A\u064A"
    ],
    LBP: [
        "Lebanese Pound",
        "\u0644\u064A\u0631\u0629 \u0644\u0628\u0646\u0627\u0646\u064A\u0629"
    ],
    LYD: [
        "Libyan Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0644\u064A\u0628\u064A"
    ],
    MAD: [
        "Moroccon Dirham",
        "\u062F\u0631\u0647\u0645 \u0645\u063A\u0631\u0628\u064A"
    ],
    MRU: [
        "Mauritanian Ouguiya",
        "\u0623\u0648\u0642\u064A\u0629 \u0645\u0648\u0631\u064A\u062A\u0627\u0646\u064A\u0629"
    ],
    MYR: [
        "Malaysian Ringgit",
        "\u0631\u064A\u0646\u063A\u064A\u062A \u0645\u0627\u0644\u064A\u0632\u064A"
    ],
    NOK: [
        "Norwegian Krone",
        "\u0643\u0631\u0648\u0646\u0629 \u0646\u0631\u0648\u064A\u062C\u064A\u0629"
    ],
    NZD: [
        "New Zealand Dollar",
        "\u062F\u0648\u0644\u0627\u0631 \u0646\u064A\u0648\u0632\u064A\u0644\u0646\u062F\u064A"
    ],
    OMR: [
        "Omani Riyal",
        "\u0631\u064A\u0627\u0644 \u0639\u0645\u0627\u0646\u064A"
    ],
    QAR: [
        "Qatari Riyal",
        "\u0631\u064A\u0627\u0644 \u0642\u0637\u0631\u064A"
    ],
    RUB: [
        "Russian Ruble",
        "\u0631\u0648\u0628\u0644 \u0631\u0648\u0633\u064A"
    ],
    SAR: [
        "Saudi Riyal",
        "\u0631\u064A\u0627\u0644 \u0633\u0639\u0648\u062F\u064A"
    ],
    SDG: [
        "Sudanese Pound",
        "\u062C\u0646\u064A\u0647 \u0633\u0648\u062F\u0627\u0646\u064A"
    ],
    SEK: [
        "Swedish Krona",
        "\u0643\u0631\u0648\u0646 \u0633\u0648\u064A\u062F\u064A"
    ],
    SGD: [
        "Singapore Dollar",
        "\u062F\u0648\u0644\u0627\u0631 \u0633\u0646\u063A\u0627\u0641\u0648\u0631\u064A"
    ],
    SYP: [
        "Syrian pound",
        "\u0644\u064A\u0631\u0629 \u0633\u0648\u0631\u064A\u0629"
    ],
    TND: [
        "Tunisian Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u062A\u0648\u0646\u0633\u064A"
    ],
    TRY: [
        "Turkish Lira",
        "\u0644\u064A\u0631\u0629 \u062A\u0631\u0643\u064A\u0629"
    ],
    VES: [
        "Venezuelan Bolivare",
        "\u0628\u0648\u0644\u064A\u0641\u0627\u0631 \u0641\u0646\u0632\u0648\u064A\u0644\u064A"
    ],
    XAF: [
        "Chad Franc",
        "\u0641\u0631\u0646\u0643 \u062A\u0634\u0627\u062F"
    ],
    YER: [
        "Yemen Rial",
        "\u0631\u064A\u0627\u0644 \u064A\u0645\u0646\u064A"
    ],
    ZAR: [
        "zuid-afrikaanse rand",
        "\u0631\u0627\u0646\u062F \u0623\u0641\u0631\u064A\u0642\u064A"
    ]
};
const getStaticProps = async (context)=>{
    const { id  } = context.params;
    const data = await fetch("https://syria-exchange.com/panel/v1/api/international-coins.php");
    const internationalCoinsData = await data.json();
    const coins = internationalCoinsData?.inter_coins?.filter((item)=>{
        for (let [key, value] of Object.entries(item)){
            if (key === id) return true;
        }
        return false;
    }).map((item)=>{
        for (let [key, value] of Object.entries(item)){
            return value;
        }
    })?.[0];
    return {
        props: {
            coins,
            internationalCoinsData
        },
        revalidate: 60
    };
};
const getStaticPaths = async ()=>{
    const data = await fetch("https://syria-exchange.com/panel/v1/api/international-coins.php");
    const internationalCoinsData = await data.json();
    const paths = internationalCoinsData?.inter_coins.map((coin)=>({
            params: {
                id: `${Object.entries(coin)[0][0]}`
            }
        })
    );
    return {
        paths,
        fallback: false
    };
};
const InternationalCoinPage = ({ coins , internationalCoinsData  })=>{
    const { i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const { query: { id  } ,  } = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const title = CURRENCY_ABBRE_TO_NAME[id]?.[i18n.dir() === "rtl" ? 1 : 0];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_2__.NextSeo, {
                title: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_13___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                    async: true,
                    src: "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4833236828935969",
                    crossOrigin: "anonymous"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header111__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ScrollToTop__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Container, {
                className: "mt-4",
                as: "main",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Row, {
                    className: "justify-content-lg-center justify-content-xl-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Col, {
                            lg: 9,
                            xl: 8,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_turkish_currency_exchange_rate_InterCoinCER__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    title: title,
                                    items: coins,
                                    lastUpdated: internationalCoinsData?.last_update
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_currency_converter_CurrencyConverter__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    sectionClass: "cer mt-5"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_turkish_gold_prices_InterGoldPrices__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    title: title,
                                    abbriviation: id
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_img_fig_IMGFig2__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    sectionClass: "IMGFig2Toast "
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Col, {
                            lg: 6,
                            xl: 4,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_img_fig_IMGFig1__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                sectionClass: "m-t-15 figureIMG"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer_Footer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InternationalCoinPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 3981:
/***/ ((module) => {

module.exports = require("react-bootstrap/Figure");

/***/ }),

/***/ 5260:
/***/ ((module) => {

module.exports = require("react-bootstrap/FigureImage");

/***/ }),

/***/ 2540:
/***/ ((module) => {

module.exports = require("react-bootstrap/Nav");

/***/ }),

/***/ 972:
/***/ ((module) => {

module.exports = require("react-bootstrap/Toast");

/***/ }),

/***/ 9709:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 9012:
/***/ ((module) => {

module.exports = require("react-loading-skeleton");

/***/ }),

/***/ 4608:
/***/ ((module) => {

module.exports = require("react-usestateref");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,64,473,569,826], () => (__webpack_exec__(8984)));
module.exports = __webpack_exports__;

})();