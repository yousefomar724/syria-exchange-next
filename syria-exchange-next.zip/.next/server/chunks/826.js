"use strict";
exports.id = 826;
exports.ids = [826];
exports.modules = {

/***/ 1690:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(972);
/* harmony import */ var react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5941);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_usestateref__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4608);
/* harmony import */ var react_usestateref__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_usestateref__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_3__]);
swr__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const iter_curr_array = [
    [
        "7",
        "USD",
        "USA Dollad",
        "\u062F\u0648\u0644\u0627\u0631 \u0627\u0645\u0631\u064A\u0643\u064A"
    ],
    [
        "7",
        "AED",
        "Emirati Dirham",
        "\u062F\u0631\u0647\u0645 \u0625\u0645\u0627\u0631\u0627\u062A\u064A"
    ],
    [
        "15",
        "AUD",
        "Australian Dollar",
        "\u062F\u0648\u0644\u0627\u0631\u0627\u0633\u062A\u0631\u0627\u0644\u064A"
    ],
    [
        "11",
        "BHD",
        "Bahraini Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0628\u062D\u0631\u064A\u0646\u064A"
    ],
    [
        "26",
        "BRL",
        "Brazilian Real",
        "\u0631\u064A\u0627\u0644 \u0628\u0631\u0627\u0632\u064A\u0644\u064A"
    ],
    [
        "12",
        "CAD",
        "Canadian Dollar",
        "\u062F\u0648\u0644\u0627\u0631 \u0643\u0646\u062F\u064A"
    ],
    [
        "13",
        "CHF",
        "Swiss Franc",
        "\u0641\u0631\u0646\u0643 \u0633\u0648\u064A\u0633\u0631\u064A"
    ],
    [
        "29",
        "CNY",
        "Chinese Renminbi",
        "\u064A\u0648\u0627\u0646 \u0635\u064A\u0646\u064A"
    ],
    [
        "38",
        "COP",
        "Colombian Pesos",
        "\u0628\u064A\u0632\u0648 \u0643\u0648\u0644\u0648\u0645\u0628\u064A"
    ],
    [
        "36",
        "DJF",
        "Djibouti Franc",
        "\u0641\u0631\u0646\u0643 \u062C\u064A\u0628\u0648\u062A\u064A"
    ],
    [
        "25",
        "DKK",
        "Danish Krone",
        "\u0643\u0631\u0648\u0646\u0629 \u062F\u0646\u0645\u0627\u0631\u0643\u064A\u0629"
    ],
    [
        "20",
        "DZD",
        "Algerian Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u062C\u0632\u0627\u0626\u0631\u064A"
    ],
    [
        "17",
        "EGP",
        "Egyptian Pound",
        "\u062C\u0646\u064A\u0647 \u0645\u0635\u0631\u064A"
    ],
    [
        "3",
        "EUR",
        "Euro",
        "\u064A\u0648\u0631\u0648"
    ],
    [
        "14",
        "GBP",
        "Pound Sterling",
        "\u062C\u0646\u064A\u0647 \u0625\u0633\u062A\u0631\u0644\u064A\u0646\u064A"
    ],
    [
        "27",
        "IDR",
        "Indonesian Rupiah",
        "\u0631\u0648\u0628\u064A\u0629 \u0625\u0646\u062F\u0648\u0646\u064A\u0633\u064A\u0629"
    ],
    [
        "18",
        "IQD",
        "Iraqi Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0639\u0631\u0627\u0642\u064A "
    ],
    [
        "30",
        "IRR",
        "Iranian Rial",
        "\u0631\u064A\u0627\u0644 \u0625\u064A\u0631\u0627\u0646\u064A"
    ],
    [
        "8",
        "JOD",
        "Jordanian Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0623\u0631\u062F\u0646\u064A"
    ],
    [
        "28",
        "JPY",
        "Japanese Yen",
        "\u064A\u0646 \u064A\u0627\u0628\u0627\u0646\u064A"
    ],
    [
        "6",
        "KWD",
        "Kuwaiti Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0643\u0648\u064A\u062A\u064A"
    ],
    [
        "32",
        "LBP",
        "Lebanese Pound",
        "\u0644\u064A\u0631\u0629 \u0644\u0628\u0646\u0627\u0646\u064A\u0629"
    ],
    [
        "16",
        "LYD",
        "Libyan Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u0644\u064A\u0628\u064A"
    ],
    [
        "19",
        "MAD",
        "Moroccon Dirham",
        "\u062F\u0631\u0647\u0645 \u0645\u063A\u0631\u0628\u064A"
    ],
    [
        "35",
        "MRU",
        "Mauritanian Ouguiya",
        "\u0623\u0648\u0642\u064A\u0629 \u0645\u0648\u0631\u064A\u062A\u0627\u0646\u064A\u0629"
    ],
    [
        "40",
        "MYR",
        "Malaysian Ringgit",
        "\u0631\u064A\u0646\u063A\u064A\u062A \u0645\u0627\u0644\u064A\u0632\u064A"
    ],
    [
        "24",
        "NOK",
        "Norwegian Krone",
        "\u0643\u0631\u0648\u0646\u0629 \u0646\u0631\u0648\u064A\u062C\u064A\u0629"
    ],
    [
        "41",
        "NZD",
        "New Zealand Dollar",
        "\u062F\u0648\u0644\u0627\u0631 \u0646\u064A\u0648\u0632\u064A\u0644\u0646\u062F\u064A"
    ],
    [
        "9",
        "OMR",
        "Omani Riyal",
        "\u0631\u064A\u0627\u0644 \u0639\u0645\u0627\u0646\u064A"
    ],
    [
        "10",
        "QAR",
        "Qatari Riyal",
        "\u0631\u064A\u0627\u0644 \u0642\u0637\u0631\u064A"
    ],
    [
        "23",
        "RUB",
        "Russian Ruble",
        "\u0631\u0648\u0628\u0644 \u0631\u0648\u0633\u064A"
    ],
    [
        "5",
        "SAR",
        "Saudi Riyal",
        "\u0631\u064A\u0627\u0644 \u0633\u0639\u0648\u062F\u064A"
    ],
    [
        "33",
        "SDG",
        "Sudanese Pound",
        "\u062C\u0646\u064A\u0647 \u0633\u0648\u062F\u0627\u0646\u064A"
    ],
    [
        "22",
        "SEK",
        "Swedish Krona",
        "\u0643\u0631\u0648\u0646 \u0633\u0648\u064A\u062F\u064A"
    ],
    [
        "39",
        "SGD",
        "Singapore Dollar",
        "\u062F\u0648\u0644\u0627\u0631 \u0633\u0646\u063A\u0627\u0641\u0648\u0631\u064A"
    ],
    [
        "2",
        "SYP",
        "Syrian pound",
        "\u0644\u064A\u0631\u0629 \u0633\u0648\u0631\u064A\u0629"
    ],
    [
        "21",
        "TND",
        "Tunisian Dinar",
        "\u062F\u064A\u0646\u0627\u0631 \u062A\u0648\u0646\u0633\u064A"
    ],
    [
        "4",
        "TRY",
        "Turkish Lira",
        "\u0644\u064A\u0631\u0629 \u062A\u0631\u0643\u064A\u0629"
    ],
    [
        "31",
        "VES",
        "Venezuelan Bolivare",
        "\u0628\u0648\u0644\u064A\u0641\u0627\u0631 \u0641\u0646\u0632\u0648\u064A\u0644\u064A"
    ],
    [
        "37",
        "XAF",
        "Chad Franc",
        "\u0641\u0631\u0646\u0643 \u062A\u0634\u0627\u062F"
    ],
    [
        "34",
        "YER",
        "Yemen Rial",
        "\u0631\u064A\u0627\u0644 \u064A\u0645\u0646\u064A"
    ],
    [
        "42",
        "ZAR",
        "zuid-afrikaanse rand",
        "\u0631\u0627\u0646\u062F \u0623\u0641\u0631\u064A\u0642\u064A"
    ], 
];
const CurrencyConverter = ({ sectionClass  })=>{
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const { data: coins  } = (0,swr__WEBPACK_IMPORTED_MODULE_3__["default"])("/international-coins.php");
    const [convertFrom, setConvertFrom, convertFromRef] = react_usestateref__WEBPACK_IMPORTED_MODULE_5___default()({
        currAbbreviation: "SYP",
        currName: i18n.dir() === "ltr" ? "Syrian Pound" : "\u0644\u064A\u0631\u0629 \u0633\u0648\u0631\u064A\u0629"
    });
    const [convertTo, setConvertTo, convertToRef] = react_usestateref__WEBPACK_IMPORTED_MODULE_5___default()({
        currAbbreviation: "USD",
        currName: i18n.dir() === "ltr" ? "USA Dollad" : "\u062F\u0648\u0644\u0627\u0631 \u0627\u0645\u0631\u064A\u0643\u064A"
    });
    const [valueToTransfer, setValueToTransfer, valueToTransferRef] = react_usestateref__WEBPACK_IMPORTED_MODULE_5___default()("");
    const [result, setResult, resultRef] = react_usestateref__WEBPACK_IMPORTED_MODULE_5___default()("");
    const curr1 = coins?.inter_coins.map((item)=>{
        for (let [key, value] of Object.entries(item)){
            return [
                key,
                value
            ];
        }
    });
    const handleChange = (event)=>{
        setConvertFrom({
            currAbbreviation: event.slice(0, 3),
            currName: event.slice(4)
        });
        if (valueToTransferRef != " ") {
            setValueOnChange();
        }
        if (convertFromRef.current.currAbbreviation === convertToRef.current.currAbbreviation) {
            setResult(i18n.dir() === "ltr" ? "Please Select Another Currency" : "\u064A\u0631\u062C\u0649 \u0627\u062E\u062A\u064A\u0627\u0631 \u0639\u0645\u0644\u0629 \u0627\u062E\u0631\u0649");
        }
    };
    const handleChangeTo = (event)=>{
        setConvertTo({
            currAbbreviation: event.slice(0, 3),
            currName: event.slice(4)
        });
        if (valueToTransferRef != " ") {
            setValueOnChange();
        }
        if (convertFromRef.current.currAbbreviation === convertToRef.current.currAbbreviation) {
            setResult(i18n.dir() === "ltr" ? "Please Select Another Currency" : "\u064A\u0631\u062C\u0649 \u0627\u062E\u062A\u064A\u0627\u0631 \u0639\u0645\u0644\u0629 \u0627\u062E\u0631\u0649");
        }
    };
    const changeValue = (e)=>{
        setValueToTransfer(e.target.value);
        const setValue = ()=>{
            let vv;
            const getCurrBuy = ()=>{
                curr1?.map((item)=>{
                    if (item[0] === convertFrom.currAbbreviation) {
                        item[1].map((currBuy)=>{
                            if (currBuy.curr_abbreviation === convertTo.currAbbreviation) {
                                vv = currBuy.curr_sell;
                            }
                        });
                    }
                });
            };
            getCurrBuy();
            let resulMultiply = multiply(e.target.value, vv);
            setResult(resulMultiply);
        };
        setValue();
    };
    const multiply = (num1, num2)=>{
        return num1 * num2;
    };
    const options = [
        {
            currName: i18n.dir() === "ltr" ? "Syrian Pound" : "\u0644\u064A\u0631\u0629 \u0633\u0648\u0631\u064A\u0629",
            currAbbreviation: "SYP"
        }, 
    ];
    curr1?.map((item, index)=>options.push({
            currName: i18n.dir() === "ltr" ? iter_curr_array[index][2] : iter_curr_array[index][3],
            currAbbreviation: item[0]
        })
    );
    const changeValues = ()=>{
        let temp = convertFrom;
        setConvertFrom(convertTo);
        setConvertTo(temp);
        setValueOnChange();
    };
    const setValueOnChange = ()=>{
        let vv;
        const getCurrBuy = ()=>{
            curr1.map((item)=>{
                if (item[0] === convertFromRef.current.currAbbreviation) {
                    item[1].map((currBuy)=>{
                        if (currBuy.curr_abbreviation === convertToRef.current.currAbbreviation) {
                            vv = currBuy.curr_sell;
                        }
                    });
                }
            });
        };
        getCurrBuy();
        let resulMultiply = multiply(valueToTransferRef.current, vv);
        setResult(String(resulMultiply));
    };
    let floatTo = i18n.dir() === "ltr" ? "float-left" : "float-right";
    let floatFrom = i18n.dir() === "ltr" ? "float-right" : "float-left";
    let textAlign = i18n.dir() === "ltr" ? "text-left" : "text-right";
    let imageAlign = i18n.dir() === "ltr" ? "text-right" : "text-left";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: sectionClass,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "CurrencyConverterNav",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/logo.svg",
                                    alt: "Syria Exchange",
                                    className: "img"
                                }),
                                t("description.CurrConverterTitle")
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                name: "CurrencyConverterInput",
                                className: "CurrencyConverterInput",
                                placeholder: t("description.CurrConverterPlaceHolder1"),
                                value: valueToTransfer,
                                disabled: !coins,
                                onChange: changeValue
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "CurrencyConverterToast",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: `ToastCurrencyConverterPara grid-row-start-2 ${floatFrom}`,
                        children: t("description.CurrConverterFrom")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: "grid-col-span-5 ToastCurrencyConverter grid-row-start-2 ToastCurrencyConverterBg-color",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Toast__WEBPACK_IMPORTED_MODULE_1___default().Body), {
                            className: "CurrencyConverterToastBody",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "toastFirstFragmentCurrencyConverter grid-col-span-2 ToastCurrencyConverterBorder-bg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.DropdownButton, {
                                            title: convertFrom.currName,
                                            id: "dropdown-menu-align-right",
                                            onSelect: handleChange,
                                            disabled: !coins,
                                            children: options.map((option, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Dropdown.Item, {
                                                    eventKey: [
                                                        option.currAbbreviation,
                                                        option.currName
                                                    ],
                                                    className: convertToRef.current.currAbbreviation === option.currAbbreviation ? "displayNone " : " ",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "toastFirstFragmentDropdownDiv scrollbar scrollbar-lady-lips",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: `fint-size-dropdown force-overflow ${textAlign}`,
                                                                children: option.currName
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                src: `/currIcons/${option.currAbbreviation}.png`,
                                                                className: ` currConverterCurrIcon ${imageAlign}`,
                                                                alt: option.currAbbreviation
                                                            })
                                                        ]
                                                    })
                                                }, index)
                                            )
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "ToastCurrencyConverter1Div",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                    className: "CurrencyConverterSmall",
                                                    children: convertFrom.currAbbreviation
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: `/currIcons/${convertFrom.currAbbreviation}.png`,
                                                    alt: convertFrom.currAbbreviation,
                                                    className: "CurrencyConverterFlag"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "equal",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        onClick: changeValues,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/res.png",
                                            alt: "",
                                            className: "CurrencyConverterRes"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "toastSecondFragmentCurrencyConverter grid-col-span-2 ToastCurrencyConverterBorder-bg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.DropdownButton, {
                                            title: convertTo.currName,
                                            id: "dropdown-menu-align-right",
                                            disabled: !coins,
                                            onSelect: handleChangeTo,
                                            children: options.map((option, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Dropdown.Item, {
                                                    eventKey: [
                                                        option.currAbbreviation,
                                                        option.currName
                                                    ],
                                                    className: convertFromRef.current.currAbbreviation === option.currAbbreviation ? "displayNone " : " ",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "toastFirstFragmentDropdownDiv",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: `fint-size-dropdown ${textAlign}`,
                                                                children: option.currName
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                src: `/currIcons/${option.currAbbreviation}.png`,
                                                                className: ` currConverterCurrIcon ${imageAlign}`,
                                                                alt: option.currAbbreviation
                                                            })
                                                        ]
                                                    })
                                                }, index)
                                            )
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "ToastCurrencyConverter1Div",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                    className: "CurrencyConverterSmall",
                                                    children: convertTo.currAbbreviation
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: `/currIcons/${convertTo.currAbbreviation}.png`,
                                                    alt: convertTo.currAbbreviation,
                                                    className: "CurrencyConverterFlag"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: `ToastCurrencyConverterPara grid-row-start-2 ${floatTo}`,
                        children: t("description.CurrConverterTo")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "grid-col-start-4 grid-row-start-3",
                        children: t("description.change")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "ToastCurrencyConverterResult grid-row-start-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            name: "CurrencyConverterInput",
                            className: "CurrencyConverterInput",
                            placeholder: t("description.CurrConverterPlaceHolder2"),
                            value: result,
                            readOnly: true
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrencyConverter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6120:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5941);
/* harmony import */ var react_bootstrap_Figure__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3981);
/* harmony import */ var react_bootstrap_Figure__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Figure__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_1__]);
swr__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const IMGFig2 = ({ sectionClass  })=>{
    const { data: ads  } = (0,swr__WEBPACK_IMPORTED_MODULE_1__["default"])("/ads-banner.php");
    if (!ads) {
        return null;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "cer",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: sectionClass,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Figure__WEBPACK_IMPORTED_MODULE_2___default()), {
                className: "grid-col-span-9",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: ads.ads_banner[0].banner_link,
                    target: "_blank",
                    rel: "noreferrer",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Figure__WEBPACK_IMPORTED_MODULE_2___default().Image), {
                        width: "100%",
                        height: "100%",
                        alt: ads.ads_banner[0].banner_image,
                        src: ads.ads_banner[0].banner_image
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IMGFig2);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;