"use strict";
exports.id = 64;
exports.ids = [64];
exports.modules = {

/***/ 7226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header111)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/ListItem2.js



const ListItem2 = (props)=>{
    const { anchotText , icon , iconStatus , usdClass , cityNameClass , value , value2 , curr_difference , Lihover , divmargin ,  } = props;
    const router = (0,router_.useRouter)();
    const path = router.pathname;
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        className: Lihover,
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: "/syrian-pound",
            onClick: path === "/syrian-pound" && (()=>router.reload(window.location.pathname)
            ),
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: cityNameClass,
                                children: anchotText
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: usdClass,
                                children: "USD \u062F\u0648\u0644\u0627\u0631"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: divmargin,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-number value",
                                children: value
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: curr_difference >= 0 ? "value2green font-number" : "value2red font-number",
                                children: [
                                    value2,
                                    " ",
                                    iconStatus && icon
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
ListItem2.defaultProps = {
    anchotText: "",
    style: "",
    usdClass: ""
};
/* harmony default export */ const components_ListItem2 = (ListItem2);

// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/ListItemSocial.js
var ListItemSocial = __webpack_require__(5109);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
// EXTERNAL MODULE: external "react-loading-skeleton"
var external_react_loading_skeleton_ = __webpack_require__(9012);
var external_react_loading_skeleton_default = /*#__PURE__*/__webpack_require__.n(external_react_loading_skeleton_);
;// CONCATENATED MODULE: ./components/Header111.js











const Header = ()=>{
    const { 0: showNav , 1: setShowNav  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const { t , i18n  } = (0,external_react_i18next_.useTranslation)();
    const { 0: interCoins , 1: setInterCoins  } = (0,external_react_.useState)();
    const { 0: cityCoins , 1: setCityCoins  } = (0,external_react_.useState)();
    const iter_curr_array = [
        [
            "7",
            "USD",
            "USA Dollar",
            "\u062F\u0648\u0644\u0627\u0631 \u0627\u0645\u0631\u064A\u0643\u064A"
        ],
        [
            "7",
            "AED",
            "Emirati Dirham",
            "\u062F\u0631\u0647\u0645 \u0625\u0645\u0627\u0631\u0627\u062A\u064A"
        ],
        [
            "15",
            "AUD",
            "Australian Dollar",
            "\u062F\u0648\u0644\u0627\u0631\u0627\u0633\u062A\u0631\u0627\u0644\u064A"
        ],
        [
            "11",
            "BHD",
            "Bahraini Dinar",
            "\u062F\u064A\u0646\u0627\u0631 \u0628\u062D\u0631\u064A\u0646\u064A"
        ],
        [
            "26",
            "BRL",
            "Brazilian Real",
            "\u0631\u064A\u0627\u0644 \u0628\u0631\u0627\u0632\u064A\u0644\u064A"
        ],
        [
            "12",
            "CAD",
            "Canadian Dollar",
            "\u062F\u0648\u0644\u0627\u0631 \u0643\u0646\u062F\u064A"
        ],
        [
            "13",
            "CHF",
            "Swiss Franc",
            "\u0641\u0631\u0646\u0643 \u0633\u0648\u064A\u0633\u0631\u064A"
        ],
        [
            "29",
            "CNY",
            "Chinese Renminbi",
            "\u064A\u0648\u0627\u0646 \u0635\u064A\u0646\u064A"
        ],
        [
            "38",
            "COP",
            "Colombian Pesos",
            "\u0628\u064A\u0632\u0648 \u0643\u0648\u0644\u0648\u0645\u0628\u064A"
        ],
        [
            "36",
            "DJF",
            "Djibouti Franc",
            "\u0641\u0631\u0646\u0643 \u062C\u064A\u0628\u0648\u062A\u064A"
        ],
        [
            "25",
            "DKK",
            "Danish Krone",
            "\u0643\u0631\u0648\u0646\u0629 \u062F\u0646\u0645\u0627\u0631\u0643\u064A\u0629"
        ],
        [
            "20",
            "DZD",
            "Algerian Dinar",
            "\u062F\u064A\u0646\u0627\u0631 \u062C\u0632\u0627\u0626\u0631\u064A"
        ],
        [
            "17",
            "EGP",
            "Egyptian Pound",
            "\u062C\u0646\u064A\u0647 \u0645\u0635\u0631\u064A"
        ],
        [
            "3",
            "EUR",
            "Euro",
            "\u064A\u0648\u0631\u0648"
        ],
        [
            "14",
            "GBP",
            "Pound Sterling",
            "\u062C\u0646\u064A\u0647 \u0625\u0633\u062A\u0631\u0644\u064A\u0646\u064A"
        ],
        [
            "27",
            "IDR",
            "Indonesian Rupiah",
            "\u0631\u0648\u0628\u064A\u0629 \u0625\u0646\u062F\u0648\u0646\u064A\u0633\u064A\u0629"
        ],
        [
            "18",
            "IQD",
            "Iraqi Dinar",
            "\u062F\u064A\u0646\u0627\u0631 \u0639\u0631\u0627\u0642\u064A "
        ],
        [
            "30",
            "IRR",
            "Iranian Rial",
            "\u0631\u064A\u0627\u0644 \u0625\u064A\u0631\u0627\u0646\u064A"
        ],
        [
            "8",
            "JOD",
            "Jordanian Dinar",
            "\u062F\u064A\u0646\u0627\u0631 \u0623\u0631\u062F\u0646\u064A"
        ],
        [
            "28",
            "JPY",
            "Japanese Yen",
            "\u064A\u0646 \u064A\u0627\u0628\u0627\u0646\u064A"
        ],
        [
            "6",
            "KWD",
            "Kuwaiti Dinar",
            "\u062F\u064A\u0646\u0627\u0631 \u0643\u0648\u064A\u062A\u064A"
        ],
        [
            "32",
            "LBP",
            "Lebanese Pound",
            "\u0644\u064A\u0631\u0629 \u0644\u0628\u0646\u0627\u0646\u064A\u0629"
        ],
        [
            "16",
            "LYD",
            "Libyan Dinar",
            "\u062F\u064A\u0646\u0627\u0631 \u0644\u064A\u0628\u064A"
        ],
        [
            "19",
            "MAD",
            "Moroccon Dirham",
            "\u062F\u0631\u0647\u0645 \u0645\u063A\u0631\u0628\u064A"
        ],
        [
            "35",
            "MRU",
            "Mauritanian Ouguiya",
            "\u0623\u0648\u0642\u064A\u0629 \u0645\u0648\u0631\u064A\u062A\u0627\u0646\u064A\u0629"
        ],
        [
            "40",
            "MYR",
            "Malaysian Ringgit",
            "\u0631\u064A\u0646\u063A\u064A\u062A \u0645\u0627\u0644\u064A\u0632\u064A"
        ],
        [
            "24",
            "NOK",
            "Norwegian Krone",
            "\u0643\u0631\u0648\u0646\u0629 \u0646\u0631\u0648\u064A\u062C\u064A\u0629"
        ],
        [
            "41",
            "NZD",
            "New Zealand Dollar",
            "\u062F\u0648\u0644\u0627\u0631 \u0646\u064A\u0648\u0632\u064A\u0644\u0646\u062F\u064A"
        ],
        [
            "9",
            "OMR",
            "Omani Riyal",
            "\u0631\u064A\u0627\u0644 \u0639\u0645\u0627\u0646\u064A"
        ],
        [
            "10",
            "QAR",
            "Qatari Riyal",
            "\u0631\u064A\u0627\u0644 \u0642\u0637\u0631\u064A"
        ],
        [
            "23",
            "RUB",
            "Russian Ruble",
            "\u0631\u0648\u0628\u0644 \u0631\u0648\u0633\u064A"
        ],
        [
            "5",
            "SAR",
            "Saudi Riyal",
            "\u0631\u064A\u0627\u0644 \u0633\u0639\u0648\u062F\u064A"
        ],
        [
            "33",
            "SDG",
            "Sudanese Pound",
            "\u062C\u0646\u064A\u0647 \u0633\u0648\u062F\u0627\u0646\u064A"
        ],
        [
            "22",
            "SEK",
            "Swedish Krona",
            "\u0643\u0631\u0648\u0646 \u0633\u0648\u064A\u062F\u064A"
        ],
        [
            "39",
            "SGD",
            "Singapore Dollar",
            "\u062F\u0648\u0644\u0627\u0631 \u0633\u0646\u063A\u0627\u0641\u0648\u0631\u064A"
        ],
        [
            "2",
            "SYP",
            "Syrian pound",
            "\u0644\u064A\u0631\u0629 \u0633\u0648\u0631\u064A\u0629"
        ],
        [
            "21",
            "TND",
            "Tunisian Dinar",
            "\u062F\u064A\u0646\u0627\u0631 \u062A\u0648\u0646\u0633\u064A"
        ],
        [
            "4",
            "TRY",
            "Turkish Lira",
            "\u0644\u064A\u0631\u0629 \u062A\u0631\u0643\u064A\u0629"
        ],
        [
            "31",
            "VES",
            "Venezuelan Bolivare",
            "\u0628\u0648\u0644\u064A\u0641\u0627\u0631 \u0641\u0646\u0632\u0648\u064A\u0644\u064A"
        ],
        [
            "37",
            "XAF",
            "Chad Franc",
            "\u0641\u0631\u0646\u0643 \u062A\u0634\u0627\u062F"
        ],
        [
            "34",
            "YER",
            "Yemen Rial",
            "\u0631\u064A\u0627\u0644 \u064A\u0645\u0646\u064A"
        ],
        [
            "42",
            "ZAR",
            "zuid-afrikaanse rand",
            "\u0631\u0627\u0646\u062F \u0623\u0641\u0631\u064A\u0642\u064A"
        ], 
    ];
    (0,external_react_.useEffect)(()=>{
        async function getInterCoins() {
            const request = fetch("https://syria-exchange.com/panel/v1/api/international-coins.php");
            const response = await request;
            const parsed = await response.json();
            setInterCoins(parsed);
        }
        getInterCoins();
        async function getCityCoins() {
            const request = fetch("https://syria-exchange.com/panel/v1/api/city-coins.php");
            const response = await request;
            const parsed = await response.json();
            setCityCoins(parsed);
        }
        getCityCoins();
    }, [
        i18n
    ]);
    const city_curr = cityCoins?.city_coins?.map((item)=>{
        for (let [key, value] of Object.entries(item)){
            return [
                key,
                value
            ];
        }
        return city_curr;
    });
    const curr1 = interCoins?.inter_coins?.map((item)=>{
        for (let [key, value] of Object.entries(item)){
            return [
                key,
                value
            ];
        }
        return curr1;
    });
    let textAlign = i18n.dir() === "ltr" ? "text-left" : "";
    let textAlignName = i18n.dir() === "ltr" ? "headerCurrName " : "";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        id: "header",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container d-flex header",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Navbar, {
                    expanded: showNav,
                    collapseOnSelect: true,
                    fixed: "top",
                    expand: "md",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Navbar.Toggle, {
                            onClick: ()=>setShowNav(!showNav)
                            ,
                            "aria-controls": "responsive-navbar-nav"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "logo",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/logo.gif",
                                alt: "Syria Exchange",
                                className: "img"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Navbar.Collapse, {
                            id: "responsive-navbar-nav",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav, {
                                className: "custom-nav",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                    className: "nav-menu flexy navbar",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "headerUlFlex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: router.pathname === "/" ? "HeaderActive" : "",
                                                        onClick: ()=>setShowNav(false)
                                                        ,
                                                        children: t("description.headerHome")
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/syrian-pound",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        onClick: ()=>setShowNav(false)
                                                        ,
                                                        className: router.pathname === "/syrian-pound" ? "HeaderActive" : "",
                                                        children: t("description.headerSYP")
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/gold",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        onClick: ()=>setShowNav(false)
                                                        ,
                                                        className: router.pathname === "/gold" ? "HeaderActive" : "",
                                                        children: t("description.headerGold")
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/turkish-pound",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: router.pathname === "/turkish-pound" ? "HeaderActive" : "",
                                                        onClick: ()=>setShowNav(false)
                                                        ,
                                                        children: t("description.headerTRY")
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Dropdown, {
                                                        className: "coins-dropdown",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Dropdown.Toggle, {
                                                                id: "dropdown-basic",
                                                                className: router.pathname.includes("/international-coin") && "HeaderActive",
                                                                children: t("description.headerIterCoins")
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Dropdown.Menu, {
                                                                align: "center",
                                                                children: !curr1 ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    children: "loading..."
                                                                }) : curr1.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Dropdown.Item, {
                                                                        href: `/international-coin/${curr1[index][0]}`,
                                                                        as: (link_default()),
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                            onClick: ()=>setShowNav(false)
                                                                            ,
                                                                            className: `${textAlign}`,
                                                                            style: {
                                                                                color: "black",
                                                                                display: "flex",
                                                                                alignItems: "center",
                                                                                marginBottom: ".4rem",
                                                                                fontSize: ".8rem"
                                                                            },
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                                    src: `/currIcons/${curr1[index][0]}.png`,
                                                                                    className: `p-l-05 headerCurrIcon ${textAlign}`,
                                                                                    alt: curr1[index][0]
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: `${textAlign}`,
                                                                                    children: curr1[index][0] === iter_curr_array[index][1] ? i18n.dir() === "ltr" ? iter_curr_array[index][2] : iter_curr_array[index][3] : ""
                                                                                })
                                                                            ]
                                                                        })
                                                                    }, index)
                                                                )
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/news",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        onClick: ()=>setShowNav(false)
                                                        ,
                                                        className: router.pathname === "/news" ? "HeaderActive" : "",
                                                        children: t("description.headerNews")
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "headerGetApp",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Dropdown, {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Dropdown.Toggle, {
                                                                id: "dropdown-basic",
                                                                children: t("description.headerDownload")
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Dropdown.Menu, {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Dropdown.Item, {
                                                                        href: "https://play.google.com/store/apps/details?id=com.currencyapplication.currencyapplication&hl=ar&gl=US",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            src: "/google-play-badge.png",
                                                                            alt: "googleApp",
                                                                            className: "headerAppIcon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Dropdown.Item, {
                                                                        href: "https://f.top4top.io/f_7mHee9-lFUCfMYLOYYSXyw/1658094673/2387zwh2e1.apk",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            src: "/direct-link.png",
                                                                            alt: "Apple App",
                                                                            className: "headerAppIcon"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "headerSocialIcons",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListItemSocial/* default */.Z, {
                                                    icon: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/social-icons/messenger.png",
                                                        alt: "messenger.png"
                                                    }),
                                                    iconStatus: true,
                                                    liClass: "liIcon",
                                                    linkSocial: "https://m.me/Syriaexchange "
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListItemSocial/* default */.Z, {
                                                    icon: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/social-icons/telegram.png",
                                                        alt: "telegram.png"
                                                    }),
                                                    iconStatus: true,
                                                    liClass: "liIcon",
                                                    linkSocial: "https://t.me/Syriaexchange"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListItemSocial/* default */.Z, {
                                                    icon: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/social-icons/facebook.png",
                                                        alt: "facebook.png"
                                                    }),
                                                    iconStatus: true,
                                                    liClass: "liIcon",
                                                    linkSocial: "https://www.facebook.com/Syria.exchange "
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListItemSocial/* default */.Z, {
                                                    icon: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/social-icons/instagram.png",
                                                        alt: "instagram.png"
                                                    }),
                                                    iconStatus: true,
                                                    liClass: "liIcon",
                                                    linkSocial: "https://www.instagram.com/syria.exchange/"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "languageIcons",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "submit",
                                                    onClick: ()=>{
                                                        i18n.changeLanguage("ar");
                                                        setShowNav(false);
                                                    },
                                                    className: i18n.language === "ar" ? "liLanguageActive" : "liLanguage",
                                                    children: "AR"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "submit",
                                                    onClick: ()=>{
                                                        i18n.changeLanguage("en");
                                                        setShowNav(false);
                                                    },
                                                    className: i18n.language === "en" ? "liLanguageActive" : "liLanguage",
                                                    children: "EN"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: city_curr ? /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        className: "nav-menu2 ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "justify-content-center",
                            children: city_curr[0][1].slice(0, 7).map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(components_ListItem2, {
                                    Lihover: i18n.dir() === "ltr" ? "Lihover UlHeaderBorderleft " : "Lihover",
                                    city_curr_nameToShow: i18n.dir() === "ltr" ? item.curr_en_name : item.curr_ar_name,
                                    city_curr_Ename: item.curr_en_name,
                                    anchotText: i18n.dir() === "ltr" ? item.curr_en_name.toUpperCase() : item.curr_ar_name,
                                    usdClass: "usdClass",
                                    cityNameClass: i18n.dir() === "ltr" ? "marginDivEN cityNameClass" : "marginDivAR cityNameClass",
                                    divmargin: i18n.dir() === "ltr" ? "marginDivEN" : "marginDivAR",
                                    value: item.curr_sell,
                                    value2: item.curr_status,
                                    curr_difference: item.curr_difference,
                                    icon: item.curr_difference >= 0 ? /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiArrowUpSLine, {
                                        className: "value2arrowUp"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiArrowDownSLine, {
                                        className: "value2arrowDown"
                                    }),
                                    iconStatus: true
                                }, item.id)
                            )
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "d-flex justify-content-center nav-menu2-skeleton",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "d-flex align-items-start m-0 p-0",
                            children: Array.from({
                                length: 7
                            }).map((_, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: index > 2 ? "hidden-xs" : "",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "d-flex mt-1",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex flex-column align-items-center mx-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
                                                        width: 40,
                                                        height: 10,
                                                        style: {
                                                            opacity: 0.2
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
                                                        width: 30,
                                                        height: 8,
                                                        style: {
                                                            opacity: 0.2
                                                        }
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex flex-column align-items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
                                                        width: 40,
                                                        height: 10,
                                                        style: {
                                                            opacity: 0.2
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
                                                        width: 30,
                                                        height: 8,
                                                        style: {
                                                            opacity: 0.2
                                                        }
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, index)
                            )
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const Header111 = (Header);


/***/ }),

/***/ 5109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const ListItemSocial = ({ anchotText , icon , iconStatus , liClass , linkSocial ,  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
        className: liClass,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
            className: liClass,
            href: linkSocial,
            target: "_blank",
            rel: "noreferrer",
            children: [
                iconStatus && icon,
                " ",
                anchotText
            ]
        })
    });
};
ListItemSocial.defaultProps = {
    anchotText: "",
    style: "",
    liClass: "",
    link: "#",
    linkSocial: ""
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListItemSocial);


/***/ }),

/***/ 3837:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ScrollToTop)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);


function ScrollToTop() {
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        window.scrollTo(0, 0);
    }, [
        pathname
    ]);
    return null;
};


/***/ }),

/***/ 4620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2540);
/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ListItemSocial__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5109);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_4__);





const Footer = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_1___default()), {
        className: "footer",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "div1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/logo.svg",
                        alt: ""
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/advertise-with-us",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: t("description.AdvertiseWithUs")
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/get-api",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: t("description.GetApi")
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/about-us",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: t("description.AboutUs")
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/privacy-policy",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: t("description.PrivacyPolicy.title")
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/user-agreement",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: t("description.UserAgreement.title")
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "getApp",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        children: t("description.headerDownload")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://play.google.com/store/apps/details?id=com.currencyapplication.currencyapplication&hl=ar&gl=US",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/google-play-badge.png",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://f.top4top.io/f_7mHee9-lFUCfMYLOYYSXyw/1658094673/2387zwh2e1.apk",
                                className: "pl-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/direct-link.png",
                                    alt: ""
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "copyrights",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        className: "color-white",
                        children: t("description.copyRights")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                        className: "color-white",
                        children: "Syria exchange 2022"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "headerSocialIcons",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ListItemSocial__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/social-icons/messenger.png",
                                    style: {
                                        width: "90%"
                                    },
                                    alt: "messenger"
                                }),
                                iconStatus: true,
                                liClass: "liIcon",
                                linkSocial: "https://m.me/Syriaexchange "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ListItemSocial__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/social-icons/telegram.png",
                                    style: {
                                        width: "90%"
                                    },
                                    alt: "telegram"
                                }),
                                iconStatus: true,
                                liClass: "liIcon",
                                linkSocial: "https://t.me/Syriaexchange"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ListItemSocial__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/social-icons/facebook.png",
                                    style: {
                                        width: "90%"
                                    },
                                    alt: "facebook"
                                }),
                                iconStatus: true,
                                liClass: "liIcon",
                                linkSocial: "https://www.facebook.com/Syria.exchange "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ListItemSocial__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/social-icons/instagram.png",
                                    style: {
                                        width: "90%"
                                    },
                                    alt: "instagram"
                                }),
                                iconStatus: true,
                                liClass: "liIcon",
                                linkSocial: "https://www.instagram.com/syria.exchange/"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ })

};
;