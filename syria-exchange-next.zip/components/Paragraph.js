const Paragraph = ({ pText }) => {
  return (
    <>
      <p>{pText}</p>
    </>
  )
}

export default Paragraph
